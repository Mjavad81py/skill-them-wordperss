#!/usr/bin/env python3
"""Generate an Elementor-ready WordPress theme and its companion widgets plugin.

Copies assets/theme-boilerplate/ and assets/widgets-plugin/ into an output directory,
replacing every placeholder token with project-specific names.

Shop mode (WooCommerce integration) is decided in this order:
  1. --shop / --no-shop if given explicitly
  2. otherwise inferred from --brief / --name / --slug keywords

Usage:
    python3 scaffold.py --slug acme-theme --name "Acme Theme" --namespace Acme \
        --author "Acme Studio" --out ./build

    # Force a WooCommerce store theme:
    python3 scaffold.py --slug acme-shop --name "Acme Shop" --shop --out ./build

    # Let the brief decide:
    python3 scaffold.py --slug acme --name "Acme" --brief "online store for shoes" \
        --out ./build

    # Child theme of hello-elementor instead of a standalone parent:
    python3 scaffold.py --slug acme-child --name "Acme Child" --child --out ./build
"""

from __future__ import annotations

import argparse
import re
import shutil
import sys
from pathlib import Path

SKILL_ROOT = Path(__file__).resolve().parent.parent
THEME_SRC = SKILL_ROOT / "assets" / "theme-boilerplate"
PLUGIN_SRC = SKILL_ROOT / "assets" / "widgets-plugin"

BINARY_SUFFIXES = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".woff", ".woff2",
                   ".ttf", ".eot", ".zip", ".mo", ".pdf"}

# Files emitted only when the project is a shop.
SHOP_ONLY = {
    "inc/woocommerce.php",
    "woocommerce.php",
    "widgets/class-product-grid-widget.php",
}

# Signals in a project brief that imply an online store.
SHOP_KEYWORDS = (
    "shop", "store", "ecommerce", "e-commerce", "commerce", "woocommerce", "woo",
    "product", "cart", "checkout", "catalog", "catalogue", "retail", "sell",
    "فروشگاه", "فروشگاهی", "محصول", "سبد خرید", "ووکامرس", "خرید", "تجارت",
)


def looks_like_shop(text: str) -> bool:
    """Heuristic: does this project description imply a WooCommerce store?"""
    lowered = text.lower()
    return any(keyword in lowered for keyword in SHOP_KEYWORDS)


def slug_to_prefix(slug: str) -> str:
    """acme-theme -> acme_theme (safe PHP function prefix)."""
    prefix = re.sub(r"[^a-z0-9]+", "_", slug.lower()).strip("_")
    if not prefix or prefix[0].isdigit():
        prefix = "t_" + prefix
    return prefix


def slug_to_namespace(slug: str) -> str:
    """acme-theme -> AcmeTheme."""
    parts = re.split(r"[^A-Za-z0-9]+", slug)
    return "".join(p.capitalize() for p in parts if p) or "Theme"


def validate(args: argparse.Namespace) -> None:
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", args.slug):
        sys.exit(f"error: --slug must be lowercase letters, digits and hyphens: {args.slug!r}")
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", args.namespace):
        sys.exit(f"error: --namespace must be a valid PHP identifier: {args.namespace!r}")


def build_tokens(args: argparse.Namespace) -> dict[str, str]:
    prefix = args.prefix or slug_to_prefix(args.slug)
    return {
        "{{SLUG}}": args.slug,
        "{{THEME_NAME}}": args.name,
        "{{NAMESPACE}}": args.namespace,
        "{{PREFIX}}": prefix,
        "{{CONST_PREFIX}}": prefix.upper(),
        "{{TEXTDOMAIN}}": args.textdomain or args.slug,
        "{{AUTHOR}}": args.author,
    }


def substitute(text: str, tokens: dict[str, str]) -> str:
    for token, value in tokens.items():
        text = text.replace(token, value)
    return text


def copy_tree(src: Path, dest: Path, tokens: dict[str, str], force: bool,
              shop: bool = True) -> int:
    """Copy src to dest, substituting tokens in file contents and names."""
    if dest.exists():
        if not force:
            sys.exit(f"error: {dest} already exists (use --force to overwrite)")
        shutil.rmtree(dest)

    count = 0
    for item in sorted(src.rglob("*")):
        rel = item.relative_to(src)

        # Skip WooCommerce files for non-shop projects.
        if not shop and rel.as_posix() in SHOP_ONLY:
            continue

        target = dest / Path(*[substitute(part, tokens) for part in rel.parts])

        if item.is_dir():
            target.mkdir(parents=True, exist_ok=True)
            continue

        target.parent.mkdir(parents=True, exist_ok=True)

        if item.suffix.lower() in BINARY_SUFFIXES:
            shutil.copy2(item, target)
        else:
            content = substitute(item.read_text(encoding="utf-8"), tokens)
            if not shop:
                content = strip_shop_references(content, rel.as_posix())
            target.write_text(content, encoding="utf-8")
        count += 1

    return count


def strip_shop_references(content: str, rel_path: str) -> str:
    """Remove references to WooCommerce files that were not generated."""
    if rel_path == "functions.php":
        lines = [
            line for line in content.splitlines()
            if "inc/woocommerce.php" not in line
            and "// WooCommerce. Self-gating" not in line
        ]
        return "\n".join(lines).rstrip() + "\n"

    if rel_path == "includes/class-plugin.php":
        # Drop the conditional Product_Grid registration block.
        out, skip = [], 0
        for line in content.splitlines():
            if "Shop widgets only exist" in line:
                skip = 4  # comment + if + assignment + closing brace
            if skip:
                skip -= 1
                continue
            out.append(line)
        return "\n".join(out).rstrip() + "\n"

    return content


CHILD_STYLE = """/*
Theme Name: {name}
Theme URI: https://example.com/{slug}
Description: A child theme of Hello Elementor for {name}.
Author: {author}
Template: hello-elementor
Version: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: {textdomain}
*/

/* Add custom styles below. Keep design tokens in sync with Elementor Site Settings. */
"""

CHILD_FUNCTIONS = """<?php
/**
 * {name} child theme functions.
 *
 * @package {namespace}
 */

defined( 'ABSPATH' ) || exit;

define( '{const_prefix}_VERSION', '1.0.0' );

/**
 * Load the child stylesheet after the parent's.
 *
 * @return void
 */
function {prefix}_enqueue_styles() {{
	wp_enqueue_style(
		'{slug}',
		get_stylesheet_directory_uri() . '/style.css',
		array( 'hello-elementor', 'hello-elementor-theme-style' ),
		{const_prefix}_VERSION
	);
}}
add_action( 'wp_enqueue_scripts', '{prefix}_enqueue_styles', 20 );

/**
 * Register additional Elementor Theme Builder locations.
 *
 * @param \\ElementorPro\\Modules\\ThemeBuilder\\Classes\\Locations_Manager $manager Locations manager.
 * @return void
 */
function {prefix}_register_elementor_locations( $manager ) {{
	$manager->register_location(
		'sidebar',
		array(
			'label'           => esc_html__( 'Sidebar', '{textdomain}' ),
			'multiple'        => true,
			'edit_in_content' => false,
		)
	);
}}
add_action( 'elementor/theme/register_locations', '{prefix}_register_elementor_locations', 20 );
"""


def write_child_theme(dest: Path, args: argparse.Namespace, tokens: dict[str, str],
                      force: bool) -> None:
    if dest.exists():
        if not force:
            sys.exit(f"error: {dest} already exists (use --force to overwrite)")
        shutil.rmtree(dest)

    dest.mkdir(parents=True)
    (dest / "style.css").write_text(
        CHILD_STYLE.format(name=args.name, slug=args.slug, author=args.author,
                           textdomain=tokens["{{TEXTDOMAIN}}"]),
        encoding="utf-8")
    (dest / "functions.php").write_text(
        CHILD_FUNCTIONS.format(name=args.name, slug=args.slug,
                               namespace=args.namespace,
                               prefix=tokens["{{PREFIX}}"],
                               const_prefix=tokens["{{CONST_PREFIX}}"],
                               textdomain=tokens["{{TEXTDOMAIN}}"]),
        encoding="utf-8")
    (dest / "languages").mkdir()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--slug", required=True, help="Theme folder slug, e.g. acme-theme")
    parser.add_argument("--name", required=True, help='Human name, e.g. "Acme Theme"')
    parser.add_argument("--namespace", default=None, help="PHP namespace (default: derived from slug)")
    parser.add_argument("--prefix", default=None, help="PHP function prefix (default: derived from slug)")
    parser.add_argument("--textdomain", default=None, help="Text domain (default: slug)")
    parser.add_argument("--author", default="Theme Author", help="Author name")
    parser.add_argument("--out", default="./build", help="Output directory")
    parser.add_argument("--child", action="store_true",
                        help="Generate a hello-elementor child theme instead of a parent theme")
    parser.add_argument("--no-plugin", action="store_true",
                        help="Skip the companion widgets plugin")
    parser.add_argument("--force", action="store_true", help="Overwrite existing output")

    shop_group = parser.add_mutually_exclusive_group()
    shop_group.add_argument("--shop", dest="shop", action="store_true", default=None,
                            help="Include WooCommerce integration (shop theme)")
    shop_group.add_argument("--no-shop", dest="shop", action="store_false",
                            help="Exclude WooCommerce integration (content theme)")

    parser.add_argument("--brief", default="",
                        help="Project description; used to auto-detect a shop when "
                             "neither --shop nor --no-shop is given")
    args = parser.parse_args()

    if args.namespace is None:
        args.namespace = slug_to_namespace(args.slug)

    validate(args)
    tokens = build_tokens(args)

    # Resolve shop mode: explicit flag wins, else infer from the brief/name/slug.
    if args.shop is None:
        haystack = " ".join([args.brief, args.name, args.slug])
        args.shop = looks_like_shop(haystack)
        detection = "auto-detected from brief" if args.shop else "auto-detected (no shop signals)"
    else:
        detection = "explicit flag"

    out = Path(args.out).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)

    theme_dest = out / args.slug
    plugin_dest = out / f"{args.slug}-widgets"

    print(f"Shop mode    : {'ON (WooCommerce)' if args.shop else 'OFF'}  [{detection}]")

    if args.child:
        write_child_theme(theme_dest, args, tokens, args.force)
        print(f"Child theme  -> {theme_dest}  (2 files)")
    else:
        if not THEME_SRC.is_dir():
            sys.exit(f"error: boilerplate missing at {THEME_SRC}")
        n = copy_tree(THEME_SRC, theme_dest, tokens, args.force, shop=args.shop)
        (theme_dest / "languages").mkdir(exist_ok=True)
        print(f"Theme        -> {theme_dest}  ({n} files)")

    if not args.no_plugin:
        if not PLUGIN_SRC.is_dir():
            sys.exit(f"error: boilerplate missing at {PLUGIN_SRC}")
        n = copy_tree(PLUGIN_SRC, plugin_dest, tokens, args.force, shop=args.shop)
        (plugin_dest / "languages").mkdir(exist_ok=True)
        print(f"Plugin       -> {plugin_dest}  ({n} files)")

    print("\nTokens applied:")
    for token, value in tokens.items():
        print(f"  {token:<18} {value}")

    print("\nNext steps:")
    print(f"  1. python3 {Path(__file__).parent / 'verify.py'} {theme_dest}"
          + ("" if args.no_plugin else f" {plugin_dest}"))
    print(f"  2. Copy {theme_dest.name}/ into wp-content/themes/ and activate it.")
    if not args.no_plugin:
        print(f"  3. Copy {plugin_dest.name}/ into wp-content/plugins/ and activate it.")
    print("  4. Build header/footer templates in Elementor > Templates > Theme Builder.")
    if args.shop:
        print("  5. Activate WooCommerce, then build Single Product / Product Archive")
        print("     templates (requires Elementor Pro with the WooCommerce Builder).")
    print("  6. Validate a live URL at search.google.com/test/rich-results.")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
