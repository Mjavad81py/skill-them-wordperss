#!/usr/bin/env python3
"""Static QA gate for generated Elementor themes and widget plugins.

Checks PHP syntax (when php is available), ABSPATH guards, deprecated Elementor APIs,
missing {{WRAPPER}} in selectors, unescaped output, leftover placeholder tokens, and
required theme/plugin headers.

Usage:
    python3 verify.py ./build/acme-theme ./build/acme-theme-widgets
"""

from __future__ import annotations

import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

RED, YELLOW, GREEN, DIM, RESET = "\033[31m", "\033[33m", "\033[32m", "\033[2m", "\033[0m"

DEPRECATED = {
    "elementor/widgets/widgets_registered": "use 'elementor/widgets/register'",
    "register_widget_type(": "use $widgets_manager->register()",
    "elementor/dynamic_tags/register_tags": "use 'elementor/dynamic_tags/register'",
    "register_tag(": "use $dynamic_tags_manager->register()",
    "function _register_controls": "use register_controls()",
    "function _content_template": "use content_template()",
    "elementor/element/before_section_start": "prefer elementor/element/after_section_end where possible",
}

# Echo of a bare variable / array access with no escaping function.
UNESCAPED_ECHO = re.compile(
    r"echo\s+\$(?!this->|wpdb)[A-Za-z_][A-Za-z0-9_]*(\s*\[[^\]]*\])*\s*[;.]"
)
SELECTOR_LINE = re.compile(r"['\"]([^'\"]*?)\s*['\"]\s*=>\s*['\"][^'\"]*\{\{(VALUE|SIZE|TOP)")
PLACEHOLDER = re.compile(r"\{\{[A-Z_]+\}\}")

REQUIRED_THEME_HEADERS = ["Theme Name", "Version", "License", "Text Domain"]
REQUIRED_PLUGIN_HEADERS = ["Plugin Name", "Version", "Text Domain"]

# Raw JSON-LD echoed as a string instead of built as an array + wp_json_encode.
RAW_JSONLD = re.compile(r"""echo\s+['"]\s*<script[^'"]*ld\+json""", re.IGNORECASE)


class Report:
    def __init__(self) -> None:
        self.errors: list[str] = []
        self.warnings: list[str] = []
        self.notes: list[str] = []

    def error(self, msg: str) -> None:
        self.errors.append(msg)

    def warn(self, msg: str) -> None:
        self.warnings.append(msg)

    def note(self, msg: str) -> None:
        self.notes.append(msg)


def php_available() -> bool:
    return shutil.which("php") is not None


def check_syntax(path: Path, rel: str, report: Report, use_php: bool) -> None:
    if not use_php:
        return
    result = subprocess.run(["php", "-l", str(path)], capture_output=True, text=True)
    if result.returncode != 0:
        detail = (result.stdout + result.stderr).strip().splitlines()
        report.error(f"{rel}: PHP syntax error — {detail[0] if detail else 'unknown'}")


def check_php_file(path: Path, rel: str, report: Report, use_php: bool) -> None:
    text = path.read_text(encoding="utf-8", errors="replace")
    lines = text.splitlines()

    check_syntax(path, rel, report, use_php)

    if "uninstall.php" in rel:
        if "WP_UNINSTALL_PLUGIN" not in text:
            report.error(f"{rel}: uninstall.php must guard on WP_UNINSTALL_PLUGIN")
    elif "ABSPATH" not in text:
        report.error(f"{rel}: missing `defined( 'ABSPATH' ) || exit;` guard")

    for token, advice in DEPRECATED.items():
        for i, line in enumerate(lines, 1):
            if token in line and not line.lstrip().startswith(("*", "//", "#")):
                report.error(f"{rel}:{i}: deprecated `{token}` — {advice}")

    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith(("*", "//", "#")):
            continue

        m = SELECTOR_LINE.search(line)
        if m and "{{WRAPPER}}" not in m.group(1) and "{{CURRENT_ITEM}}" not in m.group(1):
            report.error(f"{rel}:{i}: selector missing {{{{WRAPPER}}}} — styles will leak")

        if UNESCAPED_ECHO.search(line):
            report.warn(f"{rel}:{i}: possibly unescaped output — {stripped[:70]}")

    for i, line in enumerate(lines, 1):
        for m in PLACEHOLDER.finditer(line):
            if m.group(0) not in ("{{WRAPPER}}", "{{VALUE}}", "{{SIZE}}", "{{UNIT}}",
                                  "{{TOP}}", "{{RIGHT}}", "{{BOTTOM}}", "{{LEFT}}",
                                  "{{CURRENT_ITEM}}"):
                report.error(f"{rel}:{i}: unreplaced placeholder {m.group(0)}")

    if "__(" in text or "_e(" in text or "esc_html__(" in text:
        bare = re.findall(r"(?:esc_html__|esc_attr__|__|_e|_n)\(\s*'[^']*'\s*\)", text)
        for snippet in bare[:3]:
            report.warn(f"{rel}: translation call without a text domain — {snippet[:60]}")


def check_theme(root: Path, report: Report, use_php: bool) -> None:
    style = root / "style.css"
    is_child = False

    if not style.is_file():
        report.error("style.css missing — WordPress will not recognize the theme")
        header = ""
    else:
        header = style.read_text(encoding="utf-8", errors="replace")[:2000]
        is_child = bool(re.search(r"^\s*Template:\s*\S+", header, re.MULTILINE))
        for key in REQUIRED_THEME_HEADERS:
            if f"{key}:" not in header:
                report.error(f"style.css: missing required header `{key}`")

    kind = "Child theme" if is_child else "Theme"
    print(f"\n{DIM}{kind}: {root}{RESET}")

    # Child themes inherit index.php and all templates from the parent.
    if not is_child and not (root / "index.php").is_file() and not (root / "templates").is_dir():
        report.error("index.php missing — required for every WordPress theme")

    functions = root / "functions.php"
    if functions.is_file():
        text = functions.read_text(encoding="utf-8", errors="replace")
        combined = text
        for inc in (root / "inc").glob("*.php"):
            combined += inc.read_text(encoding="utf-8", errors="replace")

        if "elementor/theme/register_locations" not in combined and not is_child:
            report.warn("no Elementor location registration found — Theme Builder "
                        "templates will be ignored")
        if not is_child and "add_theme_support( 'elementor'" not in combined and \
           "add_theme_support('elementor'" not in combined:
            report.note("consider add_theme_support( 'elementor' ) to declare compatibility")
        if "Widget_Base" in combined:
            report.error("theme contains an Elementor widget — move widgets to a plugin so "
                         "switching themes does not destroy content")

        if is_child and "get_stylesheet_directory_uri" not in combined:
            report.warn("child theme does not enqueue its own stylesheet via "
                        "get_stylesheet_directory_uri()")
    else:
        report.error("functions.php missing")

    if not is_child:
        template_hits = 0
        for php in root.rglob("*.php"):
            if "elementor_theme_do_location" in php.read_text(encoding="utf-8", errors="replace"):
                template_hits += 1
        if template_hits == 0:
            report.warn("no template calls elementor_theme_do_location() — locations are "
                        "registered but never rendered")

    if not (root / "screenshot.png").is_file():
        report.note("screenshot.png missing (1200x900 recommended for distribution)")

    all_php = "".join(
        p.read_text(encoding="utf-8", errors="replace") for p in root.rglob("*.php")
    )
    check_seo(all_php, root, report, is_child)
    check_woocommerce(all_php, report, is_theme=True)

    for php in sorted(root.rglob("*.php")):
        check_php_file(php, str(php.relative_to(root)), report, use_php)


def check_seo(text: str, root: Path, report: Report, is_child: bool) -> None:
    """SEO-specific checks for a theme."""

    emits_meta = 'name="description"' in text or "name=\\\"description\\\"" in text
    emits_schema = "application/ld+json" in text

    if emits_meta or emits_schema:
        # A theme that emits SEO output MUST defer to an active SEO plugin.
        defers = (
            "WPSEO_VERSION" in text
            or "RANK_MATH_VERSION" in text
            or "seo_plugin_active" in text
        )
        if not defers:
            report.error("theme emits SEO meta/schema but never checks for an active SEO "
                         "plugin — this produces duplicate tags and split schema graphs "
                         "on sites running Yoast or Rank Math")

    if emits_schema:
        if "wp_json_encode" not in text:
            report.error("JSON-LD built without wp_json_encode() — hand-built JSON is a "
                         "syntax-error and injection risk")
        if RAW_JSONLD.search(text):
            report.warn("JSON-LD appears to be echoed as a raw string; build an array and "
                         "pass it through wp_json_encode()")
        if "@graph" not in text:
            report.note("schema nodes are not connected in an @graph — a connected graph "
                        "gives search engines better entity relationships")

    if not is_child:
        if not emits_meta:
            report.note("theme emits no meta description fallback; fine if you require an "
                        "SEO plugin, otherwise pages ship without one")
        if "og:title" not in text:
            report.note("no Open Graph tags — social shares will render without a preview")
        if "canonical" not in text:
            report.warn("no canonical URL output — paginated and duplicate views may be "
                        "indexed separately")

    # Core Web Vitals.
    if "fetchpriority" not in text:
        report.note("no fetchpriority hint for the LCP image — the highest-impact "
                    "Core Web Vitals fix available to a theme")

    # Accessibility / on-page structure.
    header = root / "header.php"
    if header.is_file():
        head_text = header.read_text(encoding="utf-8", errors="replace")
        if "skip-link" not in head_text and "skip to" not in head_text.lower():
            report.note("no skip link in header.php")
        if "language_attributes" not in head_text:
            report.error("header.php missing language_attributes() on <html> — required "
                         "for correct lang/dir and RTL support")


def check_woocommerce(text: str, report: Report, is_theme: bool) -> None:
    """WooCommerce-specific checks; silent for projects with no shop code."""

    # Only audit projects that actually integrate a shop. Incidental, guarded
    # references (e.g. a breadcrumb that checks function_exists( 'is_shop' ))
    # must not trigger shop warnings on a content-only theme.
    strong_signals = (
        "add_theme_support( 'woocommerce'",
        "add_theme_support('woocommerce'",
        "woocommerce_content(",
        "wc_get_product(",
        "WC_Product",
        "is_woocommerce()",
        "woocommerce_template_loop",
        "wc_product_class(",
    )
    if not any(signal in text for signal in strong_signals):
        return

    declares_support = "add_theme_support( 'woocommerce'" in text or \
                       "add_theme_support('woocommerce'" in text

    if is_theme and not declares_support:
        report.warn("WooCommerce referenced but add_theme_support( 'woocommerce' ) is "
                    "missing — WooCommerce will fall back to shortcode rendering and "
                    "ignore template overrides")

    if declares_support:
        for feature in ("wc-product-gallery-zoom", "wc-product-gallery-lightbox",
                        "wc-product-gallery-slider"):
            if feature not in text:
                report.note(f"gallery feature '{feature}' not declared — that part of the "
                            "product gallery stays disabled")

    if "custom_order_tables" not in text:
        report.warn("no HPOS compatibility declaration (FeaturesUtil::declare_compatibility "
                    "with 'custom_order_tables') — WooCommerce will flag this as "
                    "incompatible and block High-Performance Order Storage")

    # Guarding: shop code must not fatal when WooCommerce is inactive.
    if "wc_get_product" in text or "is_woocommerce()" in text:
        guarded = "class_exists( 'WooCommerce' )" in text or \
                  'class_exists("WooCommerce")' in text or \
                  "is_woocommerce_active" in text
        if not guarded:
            report.error("WooCommerce functions called without a class_exists( 'WooCommerce' ) "
                         "guard — the site will fatal if the store plugin is deactivated")

    # Duplicate Product schema is a common and damaging mistake.
    if '"Product"' in text or "'Product'" in text:
        if "application/ld+json" in text:
            report.warn("theme/plugin appears to emit Product schema; WooCommerce already "
                        "outputs product structured data — duplicating it creates "
                        "conflicting offer nodes")


def check_plugin(root: Path, report: Report, use_php: bool) -> None:
    print(f"{DIM}Plugin: {root}{RESET}")

    main_file = None
    for php in root.glob("*.php"):
        if "Plugin Name:" in php.read_text(encoding="utf-8", errors="replace")[:2000]:
            main_file = php
            break

    if main_file is None:
        report.error("no plugin bootstrap file with a `Plugin Name:` header")
    else:
        header = main_file.read_text(encoding="utf-8", errors="replace")[:2000]
        for key in REQUIRED_PLUGIN_HEADERS:
            if f"{key}:" not in header:
                report.error(f"{main_file.name}: missing required header `{key}`")

    combined = "".join(
        p.read_text(encoding="utf-8", errors="replace") for p in root.rglob("*.php")
    )

    if "did_action( 'elementor/loaded' )" not in combined and \
       "did_action('elementor/loaded')" not in combined:
        report.error("no `did_action( 'elementor/loaded' )` check — the plugin will fatal "
                     "when Elementor is inactive")
    if "elementor/widgets/register" not in combined:
        report.warn("no widget registration found on 'elementor/widgets/register'")
    if "elementor/elements/categories_registered" not in combined:
        report.note("no custom panel category — widgets will land in 'General'")

    if "Widget_Base" in combined:
        if "get_style_depends" not in combined and "get_script_depends" not in combined:
            report.note("no get_style_depends()/get_script_depends() — assets may load "
                        "site-wide instead of conditionally")

    if "WP_Query" in combined and "wp_reset_postdata" not in combined:
        report.error("WP_Query used without wp_reset_postdata() — will corrupt the main loop")

    check_woocommerce(combined, report, is_theme=False)

    for php in sorted(root.rglob("*.php")):
        check_php_file(php, str(php.relative_to(root)), report, use_php)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("paths", nargs="+", help="Theme and/or plugin directories")
    parser.add_argument("--strict", action="store_true", help="Treat warnings as failures")
    args = parser.parse_args()

    use_php = php_available()
    if not use_php:
        print(f"{YELLOW}note:{RESET} `php` not found — skipping syntax checks")

    report = Report()

    for raw in args.paths:
        root = Path(raw).expanduser().resolve()
        if not root.is_dir():
            report.error(f"{raw}: not a directory")
            continue

        is_plugin = any(
            "Plugin Name:" in p.read_text(encoding="utf-8", errors="replace")[:2000]
            for p in root.glob("*.php")
        )

        if is_plugin:
            check_plugin(root, report, use_php)
        else:
            check_theme(root, report, use_php)

    print()
    for msg in report.errors:
        print(f"{RED}ERROR{RESET}  {msg}")
    for msg in report.warnings:
        print(f"{YELLOW}WARN {RESET}  {msg}")
    for msg in report.notes:
        print(f"{DIM}note   {msg}{RESET}")

    total = len(report.errors) + len(report.warnings)
    print()
    if report.errors:
        print(f"{RED}FAILED{RESET}  {len(report.errors)} error(s), "
              f"{len(report.warnings)} warning(s), {len(report.notes)} note(s)")
        return 1
    if report.warnings and args.strict:
        print(f"{RED}FAILED{RESET}  {len(report.warnings)} warning(s) under --strict")
        return 1
    if total == 0:
        print(f"{GREEN}PASSED{RESET}  no issues found "
              f"({len(report.notes)} note(s))")
    else:
        print(f"{GREEN}PASSED{RESET}  {len(report.warnings)} warning(s), "
              f"{len(report.notes)} note(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
