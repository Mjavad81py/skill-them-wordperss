<?php
/**
 * Template tags used by the fallback markup.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

/**
 * Print the site branding: logo when set, otherwise the site title.
 *
 * @return void
 */
function {{PREFIX}}_site_branding() {

	if ( has_custom_logo() ) {
		the_custom_logo();
		return;
	}

	$tag = is_front_page() && is_home() ? 'h1' : 'p';

	printf(
		'<%1$s class="site-title"><a href="%2$s" rel="home">%3$s</a></%1$s>',
		esc_html( $tag ),
		esc_url( home_url( '/' ) ),
		esc_html( get_bloginfo( 'name' ) )
	);
}

/**
 * Print post meta for the fallback loop.
 *
 * @return void
 */
function {{PREFIX}}_entry_meta() {

	if ( 'post' !== get_post_type() ) {
		return;
	}

	printf(
		'<div class="entry-meta"><time class="entry-date" datetime="%1$s">%2$s</time><span class="byline">%3$s</span></div>',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() ),
		esc_html( get_the_author() )
	);
}

/**
 * Print the post thumbnail with a sensible default size.
 *
 * @param string $size Image size.
 * @return void
 */
function {{PREFIX}}_post_thumbnail( $size = 'large' ) {

	if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
		return;
	}

	echo '<figure class="post-thumbnail">';

	if ( is_singular() ) {
		the_post_thumbnail( $size );
	} else {
		printf(
			'<a href="%s" aria-hidden="true" tabindex="-1">%s</a>',
			esc_url( get_permalink() ),
			get_the_post_thumbnail( null, $size )
		);
	}

	echo '</figure>';
}

/**
 * Print the archive/singular page header when Elementor is not handling it.
 *
 * @return void
 */
function {{PREFIX}}_page_header() {

	echo '<header class="page-header">';

	if ( is_singular() ) {
		the_title( '<h1 class="entry-title">', '</h1>' );
	} else {
		the_archive_title( '<h1 class="entry-title">', '</h1>' );
		the_archive_description( '<div class="archive-description">', '</div>' );
	}

	echo '</header>';
}
