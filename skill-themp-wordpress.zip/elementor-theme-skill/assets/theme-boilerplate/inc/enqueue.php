<?php
/**
 * Asset loading.
 *
 * Keep this minimal. Widget assets are registered by the companion plugin and loaded
 * conditionally through get_style_depends() / get_script_depends().
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

/**
 * Enqueue frontend assets.
 *
 * @return void
 */
function {{PREFIX}}_enqueue_assets() {

	wp_enqueue_style(
		'{{SLUG}}',
		{{CONST_PREFIX}}_URL . '/style.css',
		array(),
		{{CONST_PREFIX}}_VERSION
	);

	wp_style_add_data( '{{SLUG}}', 'rtl', 'replace' );

	wp_enqueue_script(
		'{{SLUG}}-navigation',
		{{CONST_PREFIX}}_URL . '/assets/js/navigation.js',
		array(),
		{{CONST_PREFIX}}_VERSION,
		true
	);

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', '{{PREFIX}}_enqueue_assets' );

/**
 * Add a preconnect hint only when Elementor is actually loading Google Fonts.
 *
 * @param array  $urls           URLs to print.
 * @param string $relation_type  Relation type.
 * @return array
 */
function {{PREFIX}}_resource_hints( $urls, $relation_type ) {

	if ( 'preconnect' === $relation_type && wp_style_is( 'google-fonts-1', 'queue' ) ) {
		$urls[] = array(
			'href' => 'https://fonts.gstatic.com',
			'crossorigin',
		);
	}

	return $urls;
}
add_filter( 'wp_resource_hints', '{{PREFIX}}_resource_hints', 10, 2 );
