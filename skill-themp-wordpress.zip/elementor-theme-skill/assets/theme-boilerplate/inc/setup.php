<?php
/**
 * Theme setup.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

/**
 * Register theme supports, menus, and the text domain.
 *
 * @return void
 */
function {{PREFIX}}_setup() {

	load_theme_textdomain( '{{TEXTDOMAIN}}', {{CONST_PREFIX}}_DIR . '/languages' );

	add_theme_support( 'automatic-feed-links' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'align-wide' );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'customize-selective-refresh-widgets' );

	add_theme_support(
		'custom-logo',
		array(
			'height'      => 100,
			'width'       => 350,
			'flex-height' => true,
			'flex-width'  => true,
		)
	);

	add_theme_support(
		'html5',
		array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'script', 'style' )
	);

	// Semantic, SEO-relevant image sizes.
	add_image_size( '{{PREFIX}}-card', 600, 400, true );
	add_image_size( '{{PREFIX}}-hero', 1600, 900, true );

	// Declare Elementor compatibility.
	add_theme_support( 'elementor' );
	add_theme_support( 'elementor-pro' );
	add_theme_support( 'header-footer-elementor' );

	register_nav_menus(
		array(
			'primary' => esc_html__( 'Primary Menu', '{{TEXTDOMAIN}}' ),
			'footer'  => esc_html__( 'Footer Menu', '{{TEXTDOMAIN}}' ),
		)
	);
}
add_action( 'after_setup_theme', '{{PREFIX}}_setup' );

/**
 * Set the default content width used by Elementor and embeds.
 *
 * @return void
 */
function {{PREFIX}}_content_width() {
	if ( ! isset( $GLOBALS['content_width'] ) ) {
		$GLOBALS['content_width'] = apply_filters( '{{PREFIX}}_content_width', 1140 );
	}
}
add_action( 'after_setup_theme', '{{PREFIX}}_content_width', 0 );

/**
 * Register widget areas for installs that still rely on classic sidebars.
 *
 * @return void
 */
function {{PREFIX}}_widgets_init() {
	register_sidebar(
		array(
			'name'          => esc_html__( 'Sidebar', '{{TEXTDOMAIN}}' ),
			'id'            => '{{PREFIX}}-sidebar',
			'description'   => esc_html__( 'Shown on posts and pages using the default template.', '{{TEXTDOMAIN}}' ),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action( 'widgets_init', '{{PREFIX}}_widgets_init' );

/**
 * Expose the Elementor-oriented page templates.
 *
 * @param array $templates Existing page templates.
 * @return array
 */
function {{PREFIX}}_page_templates( $templates ) {
	$templates['templates/full-width.php'] = esc_html__( 'Elementor Full Width', '{{TEXTDOMAIN}}' );
	$templates['templates/canvas.php']     = esc_html__( 'Elementor Canvas', '{{TEXTDOMAIN}}' );

	return $templates;
}
add_filter( 'theme_page_templates', '{{PREFIX}}_page_templates' );
