<?php
/**
 * Footer shell. Delegates to the Elementor `footer` location when one is assigned.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
	</main><!-- #content -->

	<?php
	{{PREFIX}}_do_location(
		'footer',
		function () {
			get_template_part( 'template-parts/footer', 'default' );
		}
	);
	?>

</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>
