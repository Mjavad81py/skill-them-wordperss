<?php
/**
 * 404 template.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

get_header();

{{PREFIX}}_do_location(
	'single',
	function () {
		?>
		<section class="error-404 not-found">
			<header class="page-header">
				<h1 class="entry-title"><?php esc_html_e( 'Page not found', '{{TEXTDOMAIN}}' ); ?></h1>
			</header>
			<div class="page-content">
				<p><?php esc_html_e( 'That page could not be found. Try a search instead.', '{{TEXTDOMAIN}}' ); ?></p>
				<?php get_search_form(); ?>
			</div>
		</section>
		<?php
	}
);

get_footer();
