<?php
/**
 * Fallback header, used when no Elementor header template is assigned.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
<header id="masthead" class="site-header">
	<div class="site-container site-header-inner">

		<div class="site-branding">
			<?php {{PREFIX}}_site_branding(); ?>
		</div>

		<?php if ( has_nav_menu( 'primary' ) ) : ?>
			<nav id="site-navigation" class="main-navigation" aria-label="<?php esc_attr_e( 'Primary', '{{TEXTDOMAIN}}' ); ?>">
				<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false">
					<span class="menu-toggle-bar" aria-hidden="true"></span>
					<span class="screen-reader-text"><?php esc_html_e( 'Menu', '{{TEXTDOMAIN}}' ); ?></span>
				</button>
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'primary',
						'menu_id'        => 'primary-menu',
						'container'      => false,
					)
				);
				?>
			</nav>
		<?php endif; ?>

	</div>
</header>
