<?php
/**
 * Empty state for loops with no results.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
<section class="no-results not-found">

	<header class="page-header">
		<h1 class="entry-title"><?php esc_html_e( 'Nothing found', '{{TEXTDOMAIN}}' ); ?></h1>
	</header>

	<div class="page-content">
		<?php if ( is_search() ) : ?>
			<p><?php esc_html_e( 'No results matched your search. Try different keywords.', '{{TEXTDOMAIN}}' ); ?></p>
			<?php get_search_form(); ?>
		<?php else : ?>
			<p><?php esc_html_e( 'There is nothing to show here yet.', '{{TEXTDOMAIN}}' ); ?></p>
		<?php endif; ?>
	</div>

</section>
