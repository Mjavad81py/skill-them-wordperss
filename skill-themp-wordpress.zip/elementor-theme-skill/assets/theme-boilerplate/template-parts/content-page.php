<?php
/**
 * Fallback page content.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry entry-page' ); ?>>

	<?php
	if ( ! is_front_page() ) {
		{{PREFIX}}_page_header();
	}

	{{PREFIX}}_post_thumbnail( 'large' );
	?>

	<div class="entry-content">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links">' . esc_html__( 'Pages:', '{{TEXTDOMAIN}}' ),
				'after'  => '</div>',
			)
		);
		?>
	</div>

</article>
