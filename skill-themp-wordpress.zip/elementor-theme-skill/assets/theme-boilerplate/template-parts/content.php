<?php
/**
 * Fallback loop item.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'entry entry-card' ); ?>>

	<?php {{PREFIX}}_post_thumbnail( 'medium_large' ); ?>

	<div class="entry-body">
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' ); ?>
		<?php {{PREFIX}}_entry_meta(); ?>

		<div class="entry-summary">
			<?php the_excerpt(); ?>
		</div>

		<a class="entry-more" href="<?php the_permalink(); ?>">
			<?php esc_html_e( 'Read more', '{{TEXTDOMAIN}}' ); ?>
			<span class="screen-reader-text"><?php the_title(); ?></span>
		</a>
	</div>

</article>
