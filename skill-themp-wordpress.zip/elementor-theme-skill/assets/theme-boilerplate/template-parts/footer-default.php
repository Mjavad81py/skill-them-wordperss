<?php
/**
 * Fallback footer, used when no Elementor footer template is assigned.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;
?>
<footer id="colophon" class="site-footer">
	<div class="site-container site-footer-inner">

		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer', '{{TEXTDOMAIN}}' ); ?>">
				<?php
				wp_nav_menu(
					array(
						'theme_location' => 'footer',
						'menu_id'        => 'footer-menu',
						'container'      => false,
						'depth'          => 1,
					)
				);
				?>
			</nav>
		<?php endif; ?>

		<p class="site-info">
			<?php
			printf(
				/* translators: 1: year, 2: site name */
				esc_html__( '&copy; %1$s %2$s. All rights reserved.', '{{TEXTDOMAIN}}' ),
				esc_html( gmdate( 'Y' ) ),
				esc_html( get_bloginfo( 'name' ) )
			);
			?>
		</p>

	</div>
</footer>
