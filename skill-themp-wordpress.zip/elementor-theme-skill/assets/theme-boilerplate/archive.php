<?php
/**
 * Archive template. Delegates to the Elementor `archive` location when one is assigned.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

get_header();

{{PREFIX}}_do_location(
	'archive',
	function () {

		if ( ! have_posts() ) {
			get_template_part( 'template-parts/content', 'none' );
			return;
		}

		{{PREFIX}}_page_header();

		echo '<div class="post-list">';

		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', get_post_type() );
		}

		echo '</div>';

		the_posts_pagination(
			array(
				'mid_size'  => 2,
				'prev_text' => esc_html__( 'Previous', '{{TEXTDOMAIN}}' ),
				'next_text' => esc_html__( 'Next', '{{TEXTDOMAIN}}' ),
			)
		);
	}
);

get_footer();
