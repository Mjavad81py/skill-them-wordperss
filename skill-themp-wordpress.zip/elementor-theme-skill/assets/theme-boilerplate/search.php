<?php
/**
 * Search results template.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

get_header();

{{PREFIX}}_do_location(
	'archive',
	function () {

		printf(
			'<header class="page-header"><h1 class="entry-title">%s</h1></header>',
			sprintf(
				/* translators: %s: search query */
				esc_html__( 'Search results for: %s', '{{TEXTDOMAIN}}' ),
				'<span>' . esc_html( get_search_query() ) . '</span>'
			)
		);

		if ( ! have_posts() ) {
			get_template_part( 'template-parts/content', 'none' );
			return;
		}

		echo '<div class="post-list">';

		while ( have_posts() ) {
			the_post();
			get_template_part( 'template-parts/content', 'search' );
		}

		echo '</div>';

		the_posts_pagination( array( 'mid_size' => 2 ) );
	}
);

get_footer();
