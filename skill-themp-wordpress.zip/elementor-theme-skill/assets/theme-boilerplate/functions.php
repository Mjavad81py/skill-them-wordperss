<?php
/**
 * {{THEME_NAME}} functions and definitions.
 *
 * This theme is a thin shell: it registers Elementor locations and hands rendering
 * to Theme Builder templates, falling back to plain WordPress markup when Elementor
 * Pro is unavailable. It deliberately contains no Elementor widgets — those live in
 * the companion plugin so that switching themes never destroys client content.
 *
 * @package {{THEME_NAME}}
 */

defined( 'ABSPATH' ) || exit;

define( '{{CONST_PREFIX}}_VERSION', '1.0.0' );
define( '{{CONST_PREFIX}}_DIR', get_template_directory() );
define( '{{CONST_PREFIX}}_URL', get_template_directory_uri() );

require_once {{CONST_PREFIX}}_DIR . '/inc/setup.php';
require_once {{CONST_PREFIX}}_DIR . '/inc/enqueue.php';
require_once {{CONST_PREFIX}}_DIR . '/inc/elementor.php';
require_once {{CONST_PREFIX}}_DIR . '/inc/template-tags.php';

// Technical + on-page SEO. Defers entirely to an active SEO plugin.
require_once {{CONST_PREFIX}}_DIR . '/inc/seo.php';
require_once {{CONST_PREFIX}}_DIR . '/inc/schema.php';
require_once {{CONST_PREFIX}}_DIR . '/inc/performance.php';

// WooCommerce. Self-gating: harmless when the store plugin is absent.
require_once {{CONST_PREFIX}}_DIR . '/inc/woocommerce.php';
