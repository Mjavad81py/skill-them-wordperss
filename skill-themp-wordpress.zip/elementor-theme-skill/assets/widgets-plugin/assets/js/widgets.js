/**
 * Frontend handlers for {{THEME_NAME}} widgets.
 *
 * Elementor fires `frontend/element_ready/<widget-name>.default` on initial load AND
 * after every edit in the editor, so handlers registered here stay live while designing.
 */
( function ( $ ) {
	'use strict';

	$( window ).on( 'elementor/frontend/init', function () {

		if ( 'undefined' === typeof elementorFrontend ) {
			return;
		}

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/{{SLUG}}-feature-cards.default',
			function ( $scope ) {
				// $scope is the widget wrapper. Initialize per-instance behavior here.
				$scope.find( '.{{SLUG}}-card' ).each( function () {
					// Example hook point: intersection-observer reveal, counters, etc.
				} );
			}
		);

		elementorFrontend.hooks.addAction(
			'frontend/element_ready/{{SLUG}}-post-loop.default',
			function ( $scope ) {
				// Example hook point: load-more, filtering, masonry.
			}
		);
	} );

} )( jQuery );
