<?php
/**
 * Uninstall routine. Leave the database exactly as we found it.
 *
 * @package {{THEME_NAME}}Widgets
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

// Remove plugin options.
delete_option( '{{PREFIX}}_widgets_settings' );
delete_site_option( '{{PREFIX}}_widgets_settings' );

// Remove cached remote data.
delete_transient( '{{PREFIX}}_widgets_cache' );

/*
 * Deliberately NOT removed: Elementor page content containing this plugin's widgets.
 * Users who reactivate expect their layouts to still be there.
 */
