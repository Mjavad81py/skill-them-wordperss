# SEO Reference

Technical and on-page SEO for Elementor themes.

## The governing rule: defer, never duplicate

**A theme must never compete with an SEO plugin.** If Yoast, Rank Math, AIOSEO, SEOPress
or Slim SEO is active, that plugin owns titles, descriptions, canonicals, Open Graph and
the schema graph. A theme that also emits them produces:

- Two `<meta name="description">` tags — Google picks one arbitrarily.
- Two `Organization` nodes with different `@id`s — the entity graph fragments and
  Search Console reports duplicate-entity warnings.
- Conflicting canonicals — the worst case, actively harming indexation.

The generated theme detects and defers:

```php
function acme_seo_plugin_active() {
    static $active = null;
    if ( null !== $active ) {
        return $active;
    }
    $active = (
        defined( 'WPSEO_VERSION' )         // Yoast
        || defined( 'RANK_MATH_VERSION' )  // Rank Math
        || defined( 'AIOSEO_VERSION' )     // All in One SEO
        || defined( 'SEOPRESS_VERSION' )   // SEOPress
        || defined( 'SLIM_SEO_VERSION' )   // Slim SEO
        || class_exists( 'The_SEO_Framework\\Load' )
    );
    return (bool) apply_filters( 'acme_seo_plugin_active', $active );
}
```

Only when nothing is detected does the theme emit its own baseline, so a site is never
left with an empty head.

### Adding to a plugin's graph instead of competing

When you need extra data on a site that runs an SEO plugin, hook its filter rather
than printing a second script tag:

```php
// Rank Math
add_filter( 'rank_math/json_ld', function ( $data, $jsonld ) {
    foreach ( $data as $key => $node ) {
        if ( 'Organization' === ( $node['@type'] ?? '' ) ) {
            $data[ $key ]['sameAs'] = array_values( array_unique(
                array_merge( $node['sameAs'] ?? [], [ 'https://example.com/profile' ] )
            ) );
        }
    }
    return $data;
}, 99, 2 );

// Yoast — read its resolved values for the current page
$meta = function_exists( 'YoastSEO' ) ? YoastSEO()->meta->for_current_page() : false;

// Yoast — disable its JSON-LD entirely (only if you are replacing it wholesale)
add_filter( 'wpseo_json_ld_output', '__return_false' );
```

## On-page fundamentals

| Element | Rule |
| --- | --- |
| `<title>` | One per page, unique, ~50–60 chars. Use `add_theme_support( 'title-tag' )`. |
| Meta description | ~155 chars, unique, trimmed on a word boundary. |
| H1 | **Exactly one per page.** The most common Elementor regression. |
| Heading order | Never skip levels (`h1 → h2 → h3`). Make widget heading tags a control. |
| Canonical | Every indexable view. Paged archives are self-canonical, not page 1. |
| `lang` / `dir` | `<html <?php language_attributes(); ?>>` — required for RTL. |
| Images | Meaningful `alt`; explicit `width`/`height`; `srcset`. |
| Links | Descriptive anchor text, never "click here". |
| Robots | `noindex, follow` on search results, 404s, and shop utility pages. |

### The H1 problem in Elementor

Clients drag Heading widgets set to H1 into every section. Defenses:

1. Make the heading tag a control, defaulted to `h3` for card/loop widgets.
2. Never hardcode `<h1>` inside a widget.
3. Ship a debug-mode console warning (the generated theme includes one) that fires
   when a page has anything other than exactly one H1.

## Structured data (JSON-LD)

Google recommends **JSON-LD only** — not Microdata, not RDFa. Emit one connected
`@graph` rather than several disconnected script tags:

```php
$payload = array(
    '@context' => 'https://schema.org',
    '@graph'   => array( $organization, $website, $webpage, $breadcrumbs, $article ),
);
printf(
    '<script type="application/ld+json">%s</script>',
    wp_json_encode( $payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
);
```

Always build an array and pass it through `wp_json_encode()`. Hand-concatenated JSON
breaks on the first apostrophe in a site name.

### Connecting nodes with `@id`

The value of a graph is the relationships. Mint stable `@id`s and reference them:

```php
$org_id = home_url( '/' ) . '#organization';

$website['publisher']    = array( '@id' => $org_id );
$webpage['isPartOf']     = array( '@id' => $website_id );
$article['publisher']    = array( '@id' => $org_id );
$article['mainEntityOfPage'] = array( '@id' => $canonical . '#webpage' );
```

### Which types to emit

| View | Types |
| --- | --- |
| Every page | `Organization`, `WebSite`, `WebPage`, `BreadcrumbList` |
| Blog post | `BlogPosting` (or `Article`) |
| Product | **None from the theme** — WooCommerce emits `Product` itself |
| Local business | `LocalBusiness` (more specific than `Organization`) |
| FAQ section | `FAQPage` — only if the Q&A is visible on the page |

Rules: mark up only content that is actually visible; use the most specific type
available; keep required properties complete or you get no rich result at all.

### Breadcrumbs

Generate the visible trail and the `BreadcrumbList` from **one** data source so they
can never drift apart. The generated theme does this via
`acme_get_breadcrumbs()`, consumed by both `acme_breadcrumbs()` (markup) and the
schema graph. With JSON-LD present, the visible markup needs no microdata attributes.

## Core Web Vitals

Technical SEO is mostly performance. Thresholds: **LCP < 2.5s, INP < 200ms, CLS < 0.1**.

### LCP — the highest-impact theme fix

WordPress 6.3+ tries to set `fetchpriority="high"` automatically but reliably misfires
when a page builder renders the hero. Be explicit:

```php
add_action( 'wp_head', function () {
    if ( ! is_singular() || ! has_post_thumbnail() ) {
        return;
    }
    $id  = get_post_thumbnail_id();
    $src = wp_get_attachment_image_src( $id, 'large' );
    printf(
        '<link rel="preload" as="image" href="%s" imagesrcset="%s" fetchpriority="high">',
        esc_url( $src[0] ),
        esc_attr( wp_get_attachment_image_srcset( $id, 'large' ) )
    );
}, 1 );

// Never lazy-load the LCP candidate.
add_filter( 'wp_img_tag_add_loading_attr', function ( $value, $image, $context ) {
    return ( 'the_post_thumbnail' === $context && is_singular() ) ? false : $value;
}, 10, 3 );
```

Lazy-loading the hero image is the single most common LCP failure on WordPress.

### CLS

- Explicit `width`/`height` on every image (`wp_filter_content_tags()` handles content).
- `aspect-ratio` on product and card images.
- `font-display: swap` — the theme forces it onto Elementor's Google Fonts URL.
- Reserve space for anything injected after load.

### INP

- `defer` non-critical scripts.
- Avoid jQuery unless genuinely needed.
- Load widget assets conditionally via `get_script_depends()`.

### Elementor-specific performance settings

Enable in Elementor → Settings → Features:

- **Improved Asset Loading** — ships only CSS/JS for widgets in use.
- **Improved CSS Loading**
- **Inline Font Icons** — SVG instead of the Font Awesome webfont.
- **Optimized DOM Output** — fewer wrapper divs.

Self-hosting fonts: `add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );`

## Crawlability

- Clean permalinks (`/%postname%/`).
- One canonical host (www vs non-www) — redirect the other.
- HTTPS everywhere; no mixed content.
- XML sitemap: WordPress core emits one at `/wp-sitemap.xml`; SEO plugins replace it.
- `noindex` thin archives: author archives on single-author sites, date archives,
  tag archives with one post, search results, cart/checkout/account.
- Never `noindex` a page you also link internally as important.

## Validation

| Tool | Purpose |
| --- | --- |
| [Rich Results Test](https://search.google.com/test/rich-results) | Rich-result eligibility per URL |
| [Schema Markup Validator](https://validator.schema.org) | Full schema.org conformance |
| Search Console → Enhancements | Site-wide structured data errors |
| PageSpeed Insights | Core Web Vitals, field + lab data |
| `view-source:` → search `ld+json` | Count schema blocks; more than one graph means duplication |

Validate after every plugin change. Purge caches before trusting a result.
