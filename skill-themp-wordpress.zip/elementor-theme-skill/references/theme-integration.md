# Theme Integration Reference

How a WordPress theme hands control of its layout to Elementor.

## 1. Locations API (requires Elementor Pro)

Locations are named slots a Theme Builder template can be assigned to. Core locations:
`header`, `footer`, `single`, `archive`.

### Register

```php
function acme_register_elementor_locations( $elementor_theme_manager ) {

    // All four core locations at once.
    $elementor_theme_manager->register_all_core_location();

    // Or selectively:
    // $elementor_theme_manager->register_location( 'header' );
    // $elementor_theme_manager->register_location( 'footer' );

    // A custom location.
    $elementor_theme_manager->register_location(
        'sidebar',
        [
            'label'           => esc_html__( 'Sidebar', 'acme-theme' ),
            'multiple'        => true,   // allow more than one template here
            'edit_in_content' => false,  // do not use the content-area editing UI
        ]
    );
}
add_action( 'elementor/theme/register_locations', 'acme_register_elementor_locations' );
```

`register_location()` options:

| Key | Type | Meaning |
| --- | --- | --- |
| `label` | string | Human name shown in Theme Builder |
| `multiple` | bool | More than one template may target this location |
| `public` | bool | Selectable by users (default `true`) |
| `edit_in_content` | bool | Edited in the content area rather than as a standalone doc |
| `hook` | string | Auto-render on a WP action instead of an explicit call |
| `overwrite` | bool | Allow a template to replace the theme's own output |

### Render

```php
// Returns true when a Theme Builder template was printed.
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'header' ) ) {
    // Fallback markup for Elementor-free / Pro-inactive installs.
    get_template_part( 'template-parts/header', 'default' );
}
```

Guard with `function_exists()` — the function only exists with Pro active. Render each location
**exactly once** per request or the header/footer will duplicate.

Helpers:

```php
// Is a template assigned to this location right now?
\ElementorPro\Modules\ThemeBuilder\Module::instance()
    ->get_locations_manager()
    ->get_documents_for_location( 'single' );
```

## 2. Template file matrix

| File | Location | Fallback |
| --- | --- | --- |
| `header.php` | `header` | `template-parts/header-default.php` |
| `footer.php` | `footer` | `template-parts/footer-default.php` |
| `index.php` | `archive` | loop over `template-parts/content.php` |
| `archive.php` | `archive` | same |
| `search.php` | `archive` | same |
| `single.php` | `single` | `template-parts/content-single.php` |
| `page.php` | `single` | `template-parts/content-page.php` |
| `404.php` | `single` | `template-parts/404.php` |

Canonical `single.php`:

```php
<?php
defined( 'ABSPATH' ) || exit;

get_header();

if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
    while ( have_posts() ) {
        the_post();
        get_template_part( 'template-parts/content', get_post_type() );
    }
}

get_footer();
```

## 3. Required theme supports

```php
add_action( 'after_setup_theme', function () {
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'custom-logo', [
        'height'      => 100,
        'width'       => 350,
        'flex-height' => true,
        'flex-width'  => true,
    ] );
    add_theme_support( 'html5', [
        'search-form', 'comment-form', 'comment-list',
        'gallery', 'caption', 'script', 'style',
    ] );
    add_theme_support( 'align-wide' );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_theme_support( 'customize-selective-refresh-widgets' );

    // Elementor-specific.
    add_theme_support( 'elementor' );               // declares compatibility
    add_theme_support( 'elementor-pro' );
    add_theme_support( 'header-footer-elementor' ); // Elementor HF plugin support

    register_nav_menus( [
        'menu-1' => esc_html__( 'Primary', 'acme-theme' ),
        'menu-2' => esc_html__( 'Footer', 'acme-theme' ),
    ] );
} );
```

Content width (Elementor reads this for its default container):

```php
add_action( 'after_setup_theme', function () {
    if ( ! isset( $GLOBALS['content_width'] ) ) {
        $GLOBALS['content_width'] = 1140;
    }
}, 0 );
```

## 4. Page templates Elementor expects

Ship three, so users can choose per page:

- **Default** — theme header/footer + content.
- **Full width / no sidebar** — header/footer, content edge-to-edge.
- **Canvas** — nothing but the content; used for landing pages and popups.

Register in `functions.php` so Elementor's page-settings panel lists them:

```php
add_filter( 'theme_page_templates', function ( $templates ) {
    $templates['templates/full-width.php'] = esc_html__( 'Elementor Full Width', 'acme-theme' );
    $templates['templates/canvas.php']     = esc_html__( 'Elementor Canvas', 'acme-theme' );
    return $templates;
} );
```

Canvas template body:

```php
<?php
defined( 'ABSPATH' ) || exit;
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>"><?php wp_head(); ?></head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<?php while ( have_posts() ) { the_post(); the_content(); } ?>
<?php wp_footer(); ?>
</body>
</html>
```

## 5. Child-theme route (`hello-elementor`)

When the client's stack is already Hello Elementor, extend rather than replace.

`style.css`:

```css
/*
Theme Name:   Acme Child
Template:     hello-elementor
Version:      1.0.0
Text Domain:  acme-child
*/
```

`functions.php`:

```php
defined( 'ABSPATH' ) || exit;

define( 'ACME_CHILD_VERSION', '1.0.0' );

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'acme-child',
        get_stylesheet_directory_uri() . '/style.css',
        [ 'hello-elementor', 'hello-elementor-theme-style' ],
        ACME_CHILD_VERSION
    );
}, 20 );
```

Parent filters you can switch off from the child (all default to enabled):

| Filter | Effect |
| --- | --- |
| `hello_elementor_enqueue_style` | Parent reset stylesheet |
| `hello_elementor_enqueue_theme_style` | Parent theme stylesheet |
| `hello_elementor_load_textdomain` | Text domain loading |
| `hello_elementor_register_menus` | Default menu locations |
| `hello_elementor_add_theme_support` | Theme supports |
| `hello_elementor_add_woocommerce_support` | Woo gallery/zoom/lightbox |
| `hello_elementor_register_elementor_locations` | Location registration |
| `hello_elementor_content_width` | Default 800px content width |
| `hello_elementor_page_title` | Show/hide the page title |
| `hello_elementor_viewport_content` | Viewport meta content |

```php
add_filter( 'hello_elementor_page_title', '__return_false' );
```

## 6. Performance settings worth defaulting on

Elementor experiments/settings that materially reduce page weight:

- **Improved Asset Loading** + **Improved CSS Loading** — only ship CSS/JS for widgets in use.
- **Inline Font Icons** — SVG instead of the Font Awesome webfont.
- **Optimized DOM Output** — fewer wrapper divs.
- Disable Google Fonts if self-hosting: `add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );`

Never `wp_enqueue_style()` widget CSS globally in the theme; declare it per widget via
`get_style_depends()` so conditional loading works.

## 7. RTL and i18n

- Load the text domain on `after_setup_theme`; keep one text domain per package.
- Add `add_theme_support( 'rtl' )`-equivalent handling by shipping `rtl.css`; WordPress loads it
  automatically for RTL locales when it sits beside `style.css`.
- Prefer logical CSS properties (`margin-inline-start`, `padding-inline-end`) so a single
  stylesheet serves both directions.
- Elementor mirrors its own widget CSS automatically; only your custom CSS needs attention.
