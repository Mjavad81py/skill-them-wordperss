# Pre-Delivery Checklist

`scripts/verify.py` automates the static half. This is the manual pass.

## Architecture

- [ ] Widgets live in a **plugin**, not the theme — switching themes preserves content.
- [ ] Theme contains no `Widget_Base` subclass anywhere.
- [ ] Plugin functions correctly with a different theme active.
- [ ] Theme functions correctly with the widgets plugin deactivated (no fatals).
- [ ] Everything is namespaced or prefixed; no generic function names in the global scope.

## Elementor integration

- [ ] Locations registered on `elementor/theme/register_locations`.
- [ ] Every template calls `elementor_theme_do_location()` behind a `function_exists()` guard.
- [ ] Each location renders exactly once (no duplicated header/footer).
- [ ] Fallback markup renders correctly with Elementor Pro deactivated.
- [ ] Widgets registered on `elementor/widgets/register` (not the deprecated hook).
- [ ] Custom panel category registered on `elementor/elements/categories_registered`.
- [ ] All Elementor access gated behind `did_action( 'elementor/loaded' )`.
- [ ] Minimum Elementor and PHP versions declared, with admin notices when unmet.
- [ ] Full-width and canvas page templates present and selectable.

## Widgets

- [ ] `get_name()` is unique, prefixed, and final — never changed after release.
- [ ] Icon renders in the panel (valid `eicon-*` / `fa-*`).
- [ ] Widget is discoverable via `get_keywords()`.
- [ ] Every style control uses `{{WRAPPER}}` in its selectors.
- [ ] Responsive controls set for anything layout-affecting (columns, spacing, font size).
- [ ] Hover states provided where interaction is implied.
- [ ] `get_script_depends()` / `get_style_depends()` declared; nothing enqueued globally.
- [ ] `content_template()` matches `render()` output, or is deliberately omitted for PHP-only data.
- [ ] Empty state handled gracefully (and explained in the editor).
- [ ] Repeater items styled via `elementor-repeater-item-{{_id}}`, not `nth-child`.

## Dynamic behavior

- [ ] Text/URL/image controls that could be data-driven set `'dynamic' => [ 'active' => true ]`.
- [ ] `get_settings_for_display()` used in `render()` (not `get_settings()`).
- [ ] `wp_reset_postdata()` after every custom `WP_Query`.
- [ ] No queries inside `register_controls()`.
- [ ] `is_dynamic_content()` returns `true` for live-data widgets.
- [ ] External API calls cached in transients with timeouts and error fallbacks.
- [ ] AJAX endpoints verify a nonce and capability.

## SEO — deference

- [ ] Theme detects Yoast / Rank Math / AIOSEO / SEOPress / Slim SEO / TSF.
- [ ] With an SEO plugin active: theme emits **zero** meta tags and **zero** JSON-LD.
- [ ] With no SEO plugin: meta description, canonical, OG and Twitter tags all present.
- [ ] View source on a page with Yoast active — exactly one `description`, one canonical,
      one `ld+json` graph.

## SEO — on-page

- [ ] Exactly one `<h1>` per page (check the Elementor-built pages, not just fallbacks).
- [ ] Heading levels never skip; widget heading tags are controls defaulting to `h3`.
- [ ] `<html <?php language_attributes(); ?>>` present (lang + dir for RTL).
- [ ] Every image has meaningful `alt`; decorative ones are `aria-hidden`.
- [ ] Canonical correct on paged archives (self-canonical, not page 1).
- [ ] `noindex, follow` on search results and 404.
- [ ] Titles unique per view; tagline only on the front page.

## SEO — structured data

- [ ] JSON-LD built as a PHP array and passed through `wp_json_encode()`.
- [ ] One connected `@graph`, not several disconnected script tags.
- [ ] `@id`s stable and cross-referenced (`publisher`, `isPartOf`, `mainEntityOfPage`).
- [ ] Breadcrumb markup and `BreadcrumbList` come from the same data source.
- [ ] No `Product` schema emitted by the theme or widgets (WooCommerce owns it).
- [ ] Validated at [Rich Results Test](https://search.google.com/test/rich-results) — zero errors.
- [ ] Validated at [validator.schema.org](https://validator.schema.org).
- [ ] Only visible content is marked up.

## Core Web Vitals

- [ ] LCP image preloaded with `fetchpriority="high"`.
- [ ] Hero/featured image never `loading="lazy"`.
- [ ] All images have explicit `width`/`height` or `aspect-ratio`.
- [ ] `font-display: swap` on all webfonts.
- [ ] Non-critical scripts deferred.
- [ ] Elementor's Improved Asset Loading + Improved CSS Loading enabled.
- [ ] Lighthouse mobile: LCP < 2.5s, INP < 200ms, CLS < 0.1.

## WooCommerce (shop projects only)

- [ ] `add_theme_support( 'woocommerce' )` on `after_setup_theme` — without it, template
      overrides are silently ignored.
- [ ] Gallery features declared: `wc-product-gallery-zoom`, `-lightbox`, `-slider`.
- [ ] HPOS compatibility declared in **both** theme and plugin
      (`FeaturesUtil::declare_compatibility( 'custom_order_tables', … )`).
- [ ] Order meta accessed via the CRUD API, never `get_post_meta()` on order IDs.
- [ ] Every shop call guarded by `class_exists( 'WooCommerce' )`.
- [ ] Site does not fatal with WooCommerce deactivated.
- [ ] Exactly one breadcrumb source (theme / WooCommerce / SEO plugin — not two).
- [ ] Cart, checkout and account are `noindex, nofollow`.
- [ ] Product image alt falls back to the product title.
- [ ] WooCommerce CSS and `wc-cart-fragments` dequeued off shop views.
- [ ] Product grid images use `woocommerce_thumbnail`, not full size.
- [ ] Single Product and Product Archive templates built in Elementor Theme Builder.
- [ ] Add-to-cart, cart, checkout and account flows tested end to end.

## Security

- [ ] `defined( 'ABSPATH' ) || exit;` at the top of every PHP file.
- [ ] All output escaped at the point of echo.
- [ ] WYSIWYG output passed through `wp_kses_post()`.
- [ ] `SELECT` values validated against registered options.
- [ ] No direct `$_POST` / `$_GET` use without sanitization.
- [ ] `index.php` silence stubs in asset directories (or directory listing disabled).

## Performance

- [ ] Conditional asset loading verified: view a page without the widget, confirm its CSS is absent.
- [ ] No jQuery dependency unless genuinely required.
- [ ] Images sized via `Group_Control_Image_Size`, not full-size everywhere.
- [ ] Google Fonts self-hosted or disabled if the brief demands it.
- [ ] Elementor's Improved Asset Loading / Improved CSS Loading enabled.
- [ ] Front page tested in Lighthouse; no obvious render-blocking additions from the theme.

## i18n and RTL

- [ ] Single text domain per package, matching the folder slug.
- [ ] Text domain loaded on `after_setup_theme` (theme) / `plugins_loaded` (plugin).
- [ ] No variables passed as text domains (breaks string extraction).
- [ ] `/languages/` directory present with a generated `.pot`.
- [ ] RTL verified in an RTL locale; logical CSS properties used.

## Accessibility

- [ ] Heading levels are controls, not hardcoded (`h1`–`h6` select).
- [ ] Images output meaningful `alt` text from the media library.
- [ ] Interactive elements are `<button>` / `<a>`, keyboard reachable, with visible focus.
- [ ] Color contrast meets WCAG AA at default settings.
- [ ] Decorative icons marked `aria-hidden="true"`.
- [ ] `skip-link` present in the theme header.

## Manual test pass

1. Activate theme + plugin on a clean WordPress install with Elementor Pro.
2. Build a header and footer in Theme Builder; confirm they render sitewide.
3. Build a single-post and an archive template; confirm they override the fallbacks.
4. Drop every custom widget onto a page; change every control; confirm the preview updates.
5. Save and view on the frontend; confirm frontend matches the editor exactly.
6. Resize through desktop → tablet → mobile; confirm responsive controls apply.
7. Deactivate Elementor Pro; confirm fallbacks render and nothing fatals.
8. Deactivate Elementor entirely; confirm the site still loads.
9. Switch to Twenty Twenty-Five; confirm widget content survives (data intact on switch back).
10. Enable `WP_DEBUG` and `WP_DEBUG_LOG`; repeat 2–8 with a clean log.
11. Uninstall the plugin; confirm no orphan options or transients remain.
12. Install Yoast; confirm the theme's meta tags and JSON-LD disappear entirely.
13. Deactivate Yoast; confirm the theme's own tags return.
14. Run a real URL through the Rich Results Test; zero errors.
15. Shop only: activate WooCommerce, run the full purchase flow, then deactivate it and
    confirm the site still loads without fatals.

## Delivery package

- [ ] `readme.txt` / `README.md` with install steps and requirements.
- [ ] `style.css` header complete: Theme Name, URI, Author, Version, License, Text Domain, Tags.
- [ ] `screenshot.png` at 1200×900.
- [ ] Changelog started.
- [ ] `.gitignore` excluding `node_modules`, build output, and local config.
- [ ] Version numbers consistent across `style.css`, plugin header, and the version constant.
