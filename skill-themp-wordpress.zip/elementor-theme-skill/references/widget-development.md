# Widget Development Reference

## Lifecycle

```php
class Team_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name(): string { return 'acme-team-grid'; }        // unique, prefixed, permanent
    public function get_title(): string { return esc_html__( 'Team Grid', 'acme' ); }
    public function get_icon(): string { return 'eicon-gallery-grid'; }     // any eicon-* or fa-*
    public function get_categories(): array { return [ 'acme' ]; }
    public function get_keywords(): array { return [ 'team', 'staff', 'grid', 'people' ]; }

    public function get_script_depends(): array { return [ 'acme-team-grid' ]; }
    public function get_style_depends(): array { return [ 'acme-team-grid' ]; }

    public function get_custom_help_url(): string { return 'https://acme.test/docs/team-grid'; }
    public function has_widget_inner_wrapper(): bool { return false; }      // leaner DOM
    protected function is_dynamic_content(): bool { return true; }          // skip cache when data is live

    protected function register_controls(): void {}
    protected function render(): void {}            // PHP → frontend
    protected function content_template(): void {}  // Underscore.js → editor live preview
}
```

`get_name()` is a permanent contract: changing it orphans every existing instance in the database.

## Registration (Elementor 3.5+)

```php
add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
    require_once __DIR__ . '/widgets/class-team-grid-widget.php';
    $widgets_manager->register( new \Acme\Widgets\Team_Grid_Widget() );
} );
```

Deprecated — do not emit:
`elementor/widgets/widgets_registered`, `$widgets_manager->register_widget_type()`,
`_register_controls()`, `_content_template()`, `Elementor\Core\DynamicTags\Tag::_register_controls`.

Custom panel category:

```php
add_action( 'elementor/elements/categories_registered', function ( $elements_manager ) {
    $elements_manager->add_category( 'acme', [
        'title' => esc_html__( 'Acme', 'acme' ),
        'icon'  => 'fa fa-plug',
    ] );
} );
```

Unregister a core widget:

```php
add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
    $widgets_manager->unregister( 'google_maps' );
}, 20 );
```

## Control sections and tabs

```php
$this->start_controls_section( 'section_content', [
    'label' => esc_html__( 'Content', 'acme' ),
    'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
] );
// controls...
$this->end_controls_section();
```

Tabs: `TAB_CONTENT`, `TAB_STYLE`, `TAB_ADVANCED`, `TAB_LAYOUT`, `TAB_SETTINGS`.

## Control catalog

| Constant | Use |
| --- | --- |
| `TEXT`, `TEXTAREA`, `WYSIWYG`, `CODE` | Text input of increasing richness |
| `NUMBER`, `SLIDER` | Numeric; `SLIDER` supports `size_units` |
| `SELECT`, `SELECT2`, `CHOOSE`, `SWITCHER` | Choice inputs; `SELECT2` supports `multiple` |
| `COLOR`, `GRADIENT` | Color pickers, integrate with Global Colors |
| `MEDIA`, `GALLERY`, `URL`, `ICONS` | Assets and links |
| `DIMENSIONS` | top/right/bottom/left with unit |
| `REPEATER` | Repeating item groups |
| `HIDDEN`, `RAW_HTML`, `DIVIDER`, `HEADING`, `ALERT` | Panel structure and notices |
| `DATE_TIME`, `FONT`, `IMAGE_DIMENSIONS`, `POPOVER_TOGGLE` | Specialized |

Group controls (bundles of related controls):
`Group_Control_Typography`, `Group_Control_Background`, `Group_Control_Border`,
`Group_Control_Box_Shadow`, `Group_Control_Text_Shadow`, `Group_Control_Image_Size`,
`Group_Control_Css_Filter`, `Group_Control_Flex_Container`, `Group_Control_Text_Stroke`.

```php
$this->add_group_control(
    \Elementor\Group_Control_Typography::get_type(),
    [
        'name'     => 'title_typography',
        'selector' => '{{WRAPPER}} .acme-title',
    ]
);
```

## Selectors — the `{{WRAPPER}}` contract

Style controls apply CSS without you writing any, but **only** if `selectors` is scoped:

```php
$this->add_control( 'title_color', [
    'label'     => esc_html__( 'Title Color', 'acme' ),
    'type'      => \Elementor\Controls_Manager::COLOR,
    'selectors' => [
        '{{WRAPPER}} .acme-title' => 'color: {{VALUE}};',
    ],
] );
```

Token reference:

| Token | Resolves to |
| --- | --- |
| `{{WRAPPER}}` | `.elementor-element-<id>` — mandatory prefix |
| `{{VALUE}}` | The raw control value (COLOR, SELECT, TEXT) |
| `{{SIZE}}{{UNIT}}` | SLIDER / NUMBER value plus its unit |
| `{{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} …` | DIMENSIONS shorthand |
| `{{other_control_name.SIZE}}` | Cross-reference another control |

Omitting `{{WRAPPER}}` leaks styles to every instance on the page — the #1 style bug.

## Responsive and state controls

```php
$this->add_responsive_control( 'columns', [
    'label'           => esc_html__( 'Columns', 'acme' ),
    'type'            => \Elementor\Controls_Manager::SELECT,
    'default'         => '3',
    'tablet_default'  => '2',
    'mobile_default'  => '1',
    'options'         => [ '1' => '1', '2' => '2', '3' => '3', '4' => '4' ],
    'selectors'       => [
        '{{WRAPPER}} .acme-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
    ],
] );
```

Normal/hover tabs:

```php
$this->start_controls_tabs( 'style_tabs' );

  $this->start_controls_tab( 'tab_normal', [ 'label' => esc_html__( 'Normal', 'acme' ) ] );
  $this->add_control( 'bg', [
      'type'      => \Elementor\Controls_Manager::COLOR,
      'selectors' => [ '{{WRAPPER}} .acme-card' => 'background-color: {{VALUE}};' ],
  ] );
  $this->end_controls_tab();

  $this->start_controls_tab( 'tab_hover', [ 'label' => esc_html__( 'Hover', 'acme' ) ] );
  $this->add_control( 'bg_hover', [
      'type'      => \Elementor\Controls_Manager::COLOR,
      'selectors' => [ '{{WRAPPER}} .acme-card:hover' => 'background-color: {{VALUE}};' ],
  ] );
  $this->end_controls_tab();

$this->end_controls_tabs();
```

## Conditional visibility

```php
// Single condition.
'condition' => [ 'show_button' => 'yes' ],

// Value in a set.
'condition' => [ 'layout' => [ 'grid', 'masonry' ] ],

// Negation.
'condition' => [ 'layout!' => 'list' ],

// Complex AND/OR.
'conditions' => [
    'relation' => 'or',
    'terms'    => [
        [ 'name' => 'layout', 'operator' => '===', 'value' => 'grid' ],
        [ 'name' => 'columns', 'operator' => '>=', 'value' => 3 ],
    ],
],
```

`condition` hides the control in the panel; `conditions` supports operators and nesting.

## Repeaters

```php
$repeater = new \Elementor\Repeater();

$repeater->add_control( 'member_name', [
    'label'   => esc_html__( 'Name', 'acme' ),
    'type'    => \Elementor\Controls_Manager::TEXT,
    'default' => esc_html__( 'Jane Doe', 'acme' ),
    'dynamic' => [ 'active' => true ],
] );

$repeater->add_control( 'member_photo', [
    'label' => esc_html__( 'Photo', 'acme' ),
    'type'  => \Elementor\Controls_Manager::MEDIA,
] );

$this->add_control( 'members', [
    'label'       => esc_html__( 'Members', 'acme' ),
    'type'        => \Elementor\Controls_Manager::REPEATER,
    'fields'      => $repeater->get_controls(),
    'title_field' => '{{{ member_name }}}',
    'default'     => [ [ 'member_name' => esc_html__( 'Jane Doe', 'acme' ) ] ],
] );
```

Per-item styling requires the item's unique id:

```php
foreach ( $settings['members'] as $index => $item ) {
    $this->add_render_attribute( 'item' . $index, 'class', [
        'acme-member',
        'elementor-repeater-item-' . $item['_id'],
    ] );
}
```

## Render attributes and inline editing

```php
protected function render(): void {
    $settings = $this->get_settings_for_display();

    $this->add_render_attribute( 'wrapper', 'class', 'acme-grid' );
    $this->add_render_attribute( 'title', [
        'class' => 'acme-title',
    ] );
    $this->add_inline_editing_attributes( 'title', 'basic' ); // none | basic | advanced

    ?>
    <div <?php $this->print_render_attribute_string( 'wrapper' ); ?>>
        <h3 <?php $this->print_render_attribute_string( 'title' ); ?>>
            <?php echo esc_html( $settings['title'] ); ?>
        </h3>
    </div>
    <?php
}
```

`get_settings_for_display()` resolves dynamic tags; `get_settings()` returns raw values. Use the
former in `render()` almost always.

Link handling:

```php
if ( ! empty( $settings['link']['url'] ) ) {
    $this->add_link_attributes( 'button', $settings['link'] ); // url + target + nofollow + custom attrs
}
```

## content_template()

Mirrors `render()` in Underscore.js so the editor updates without a server round trip.

```php
protected function content_template(): void {
    ?>
    <div class="acme-grid">
        <# if ( settings.title ) { #>
            <h3 class="acme-title elementor-inline-editing" data-elementor-setting-key="title">
                {{{ settings.title }}}
            </h3>
        <# } #>
        <# _.each( settings.members, function( item ) { #>
            <div class="acme-member elementor-repeater-item-{{ item._id }}">
                {{{ item.member_name }}}
            </div>
        <# } ); #>
    </div>
    <?php
}
```

`{{ }}` escapes, `{{{ }}}` prints raw, `<# #>` is logic. Omit `content_template()` for widgets
whose output depends on PHP-only data (queries, APIs) — Elementor then server-renders the preview.

## Assets

```php
public function get_script_depends(): array { return [ 'acme-team-grid' ]; }
public function get_style_depends(): array  { return [ 'acme-team-grid' ]; }
```

Register (do not enqueue) the handles once in the plugin:

```php
add_action( 'elementor/frontend/after_register_scripts', function () {
    wp_register_script( 'acme-team-grid', ACME_URL . 'assets/js/team-grid.js', [ 'jquery' ], ACME_VERSION, true );
} );

add_action( 'elementor/frontend/after_register_styles', function () {
    wp_register_style( 'acme-team-grid', ACME_URL . 'assets/css/team-grid.css', [], ACME_VERSION );
} );
```

Editor-only assets: `elementor/editor/after_enqueue_scripts`,
`elementor/editor/after_enqueue_styles`. Preview iframe: `elementor/preview/enqueue_styles`.

Frontend JS handler (runs on load and after every editor edit):

```js
jQuery( window ).on( 'elementor/frontend/init', function () {
  elementorFrontend.hooks.addAction(
    'frontend/element_ready/acme-team-grid.default',
    function ( $scope ) {
      // $scope is the widget wrapper element
    }
  );
} );
```

## Security

- Escape every echo: `esc_html`, `esc_attr`, `esc_url`, `wp_kses_post`.
- Validate `SELECT` values against the registered options before use.
- Nonce + `current_user_can()` on every AJAX endpoint.
- `wp_kses_post()` for WYSIWYG output; never raw `echo $settings['html']`.
- Prepared statements for any direct `$wpdb` access.
