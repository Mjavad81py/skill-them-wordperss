# Dynamic Content Reference

Four ways to make a widget-driven theme dynamic. Pick per data source.

| Data source | Mechanism |
| --- | --- |
| Authored per widget instance | Repeater controls |
| Posts / CPTs / taxonomies | `WP_Query` inside `render()` + query controls |
| A field reused across many widgets | Custom dynamic tag |
| Slow or paginated data | AJAX endpoint + JS handler |

## 1. Dynamic tags

A tag turns a control into a live data binding. Users pick it from the database icon next to any
control that declares `'dynamic' => [ 'active' => true ]`.

### Structure

```php
class Reading_Time_Tag extends \Elementor\Core\DynamicTags\Tag {

    public function get_name(): string { return 'acme-reading-time'; }
    public function get_title(): string { return esc_html__( 'Reading Time', 'acme' ); }
    public function get_group(): array { return [ 'acme' ]; }
    public function get_categories(): array {
        return [ \Elementor\Modules\DynamicTags\Module::TEXT_CATEGORY ];
    }

    protected function register_controls(): void {
        $this->add_control( 'wpm', [
            'label'   => esc_html__( 'Words per minute', 'acme' ),
            'type'    => \Elementor\Controls_Manager::NUMBER,
            'default' => 200,
        ] );
    }

    public function render(): void {
        $wpm     = max( 1, (int) $this->get_settings( 'wpm' ) );
        $words   = str_word_count( wp_strip_all_tags( get_the_content() ) );
        $minutes = max( 1, (int) ceil( $words / $wpm ) );

        printf(
            /* translators: %d: minutes */
            esc_html( _n( '%d min read', '%d min read', $minutes, 'acme' ) ),
            $minutes
        );
    }
}
```

### Categories

Determine which controls the tag may fill:

| Constant | Fills |
| --- | --- |
| `TEXT_CATEGORY` | TEXT, TEXTAREA |
| `URL_CATEGORY` | URL |
| `IMAGE_CATEGORY` | MEDIA |
| `MEDIA_CATEGORY` | Video/audio sources |
| `POST_META_CATEGORY` | Meta-driven controls |
| `GALLERY_CATEGORY` | GALLERY |
| `NUMBER_CATEGORY` | NUMBER, SLIDER |
| `COLOR_CATEGORY` | COLOR |

Return several to make the tag broadly usable.

### Register (group first, then tag)

```php
add_action( 'elementor/dynamic_tags/register', function ( $dynamic_tags_manager ) {

    $dynamic_tags_manager->register_group( 'acme', [
        'title' => esc_html__( 'Acme', 'acme' ),
    ] );

    require_once __DIR__ . '/dynamic-tags/class-reading-time-tag.php';
    $dynamic_tags_manager->register( new \Acme\Dynamic_Tags\Reading_Time_Tag() );
} );
```

Deprecated: `elementor/dynamic_tags/register_tags`, `register_tag()`, `_register_controls()`.

### Base classes

- `\Elementor\Core\DynamicTags\Tag` — echoes markup from `render()`.
- `\Elementor\Core\DynamicTags\Data_Tag` — returns a value from `get_value()`; use for URLs,
  images, and anything consumed as data rather than printed.

```php
class Hero_Image_Tag extends \Elementor\Core\DynamicTags\Data_Tag {
    public function get_categories(): array {
        return [ \Elementor\Modules\DynamicTags\Module::IMAGE_CATEGORY ];
    }
    protected function get_value( array $options = [] ) {
        $id = (int) get_post_meta( get_the_ID(), 'hero_image_id', true );
        return $id ? [ 'id' => $id, 'url' => wp_get_attachment_image_url( $id, 'full' ) ] : [];
    }
}
```

### Enabling dynamic on a control

```php
$this->add_control( 'title', [
    'label'   => esc_html__( 'Title', 'acme' ),
    'type'    => \Elementor\Controls_Manager::TEXT,
    'dynamic' => [ 'active' => true ],
] );
```

Then read with `get_settings_for_display()` — `get_settings()` returns the unresolved tag string.

## 2. Query-driven widgets

Expose the query as controls; build the query in `render()`.

```php
protected function register_controls(): void {

    $this->start_controls_section( 'section_query', [
        'label' => esc_html__( 'Query', 'acme' ),
    ] );

    $this->add_control( 'post_type', [
        'label'   => esc_html__( 'Source', 'acme' ),
        'type'    => \Elementor\Controls_Manager::SELECT,
        'default' => 'post',
        'options' => $this->get_post_type_options(),
    ] );

    $this->add_control( 'posts_per_page', [
        'label'   => esc_html__( 'Items', 'acme' ),
        'type'    => \Elementor\Controls_Manager::NUMBER,
        'default' => 6,
        'min'     => 1,
        'max'     => 50,
    ] );

    $this->add_control( 'orderby', [
        'label'   => esc_html__( 'Order By', 'acme' ),
        'type'    => \Elementor\Controls_Manager::SELECT,
        'default' => 'date',
        'options' => [
            'date'       => esc_html__( 'Date', 'acme' ),
            'title'      => esc_html__( 'Title', 'acme' ),
            'menu_order' => esc_html__( 'Menu Order', 'acme' ),
            'rand'       => esc_html__( 'Random', 'acme' ),
        ],
    ] );

    $this->end_controls_section();
}

private function get_post_type_options(): array {
    $options = [];
    foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $type ) {
        $options[ $type->name ] = $type->label;
    }
    return $options;
}
```

```php
protected function render(): void {
    $settings = $this->get_settings_for_display();

    $query = new \WP_Query( [
        'post_type'           => sanitize_key( $settings['post_type'] ),
        'posts_per_page'      => (int) $settings['posts_per_page'],
        'orderby'             => sanitize_key( $settings['orderby'] ),
        'order'               => 'DESC',
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true, // skip pagination counting when not paginating
    ] );

    if ( ! $query->have_posts() ) {
        if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
            echo '<div class="acme-notice">' . esc_html__( 'No posts found for this query.', 'acme' ) . '</div>';
        }
        return;
    }

    echo '<div class="acme-loop">';
    while ( $query->have_posts() ) {
        $query->the_post();
        ?>
        <article <?php post_class( 'acme-loop-item' ); ?>>
            <a href="<?php the_permalink(); ?>"><?php the_title( '<h3>', '</h3>' ); ?></a>
        </article>
        <?php
    }
    echo '</div>';

    wp_reset_postdata(); // mandatory
}
```

Rules: never query in `register_controls()` (it runs on every editor panel load); always
`wp_reset_postdata()`; set `no_found_rows => true` when you are not paginating.

## 3. Editor-aware rendering

```php
use Elementor\Plugin;

$is_editor  = Plugin::$instance->editor->is_edit_mode();
$is_preview = Plugin::$instance->preview->is_preview_mode();
```

Use these to show placeholder content, explain empty states, or disable heavy API calls inside the
editor. Also declare:

```php
protected function is_dynamic_content(): bool { return true; }
```

so Elementor's CSS/HTML cache does not freeze live data.

## 4. AJAX-loaded widgets

Register the endpoint in the plugin, not the widget:

```php
add_action( 'wp_ajax_acme_load_more', 'acme_load_more' );
add_action( 'wp_ajax_nopriv_acme_load_more', 'acme_load_more' );

function acme_load_more() {
    check_ajax_referer( 'acme_nonce', 'nonce' );

    $page = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;

    $query = new \WP_Query( [
        'post_type'      => 'post',
        'posts_per_page' => 6,
        'paged'          => $page,
    ] );

    ob_start();
    while ( $query->have_posts() ) {
        $query->the_post();
        get_template_part( 'template-parts/content', 'card' );
    }
    wp_reset_postdata();

    wp_send_json_success( [
        'html'     => ob_get_clean(),
        'has_more' => $page < $query->max_num_pages,
    ] );
}
```

Localize on the registered script handle:

```php
wp_localize_script( 'acme-loop', 'AcmeLoop', [
    'ajaxUrl' => admin_url( 'admin-ajax.php' ),
    'nonce'   => wp_create_nonce( 'acme_nonce' ),
] );
```

## 5. Caching external data

```php
private function get_remote_items(): array {
    $key    = 'acme_remote_items';
    $cached = get_transient( $key );

    if ( false !== $cached ) {
        return $cached;
    }

    $response = wp_remote_get( 'https://api.example.com/items', [ 'timeout' => 8 ] );

    if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
        return [];
    }

    $items = json_decode( wp_remote_retrieve_body( $response ), true );
    $items = is_array( $items ) ? $items : [];

    set_transient( $key, $items, HOUR_IN_SECONDS );

    return $items;
}
```

Always set a `timeout`, always handle `WP_Error`, always degrade to an empty state rather than
a fatal error. Flush the transient on relevant `save_post` / settings-update hooks.

## 6. Global site settings as data

Elementor's Site Settings (colors, fonts, custom CSS) are available to widgets through globals:

```php
'global' => [
    'default' => \Elementor\Core\Kits\Documents\Tabs\Global_Colors::COLOR_PRIMARY,
],
```

Attach to a COLOR control so it inherits the site's palette by default and updates when the client
rebrands — better than a hardcoded hex default.
