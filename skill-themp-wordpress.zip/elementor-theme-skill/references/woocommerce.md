# WooCommerce Reference

## Deciding whether a project is a shop

Ask the user when the brief is ambiguous. Treat these as shop signals:
selling, products, cart, checkout, catalogue, pricing, inventory, payments,
"فروشگاه", "محصول", "سبد خرید", "ووکامرس".

The scaffolder resolves shop mode in this order:

1. `--shop` / `--no-shop` when given explicitly.
2. Otherwise inferred from `--brief`, `--name`, and `--slug`.

```bash
python3 scripts/scaffold.py --slug acme-shop --name "Acme Shop" --shop --out ./build
python3 scripts/scaffold.py --slug acme --name "Acme" --brief "online store for shoes" --out ./build
```

With shop mode off, `inc/woocommerce.php`, `woocommerce.php` and the Product Grid widget
are not generated, and their references are stripped from `functions.php` and the plugin
bootstrap. Never ship dead shop code to a content site.

## Declaring support

Without `add_theme_support( 'woocommerce' )`, WooCommerce assumes the theme is not
shop-aware and falls back to **shortcode rendering**, which silently ignores every
template override. This is the most common "my WooCommerce templates do nothing" cause.

```php
add_action( 'after_setup_theme', function () {
    add_theme_support( 'woocommerce', array(
        'thumbnail_image_width' => 400,
        'single_image_width'    => 800,
        'product_grid'          => array(
            'default_rows'    => 3,
            'min_rows'        => 1,
            'default_columns' => 3,
            'min_columns'     => 1,
            'max_columns'     => 6,
        ),
    ) );

    // Gallery features are opt-in. Omitted = that feature stays off.
    add_theme_support( 'wc-product-gallery-zoom' );
    add_theme_support( 'wc-product-gallery-lightbox' );
    add_theme_support( 'wc-product-gallery-slider' );
} );
```

If a feature is not declared, its scripts are never loaded — which is also a legitimate
performance choice.

## HPOS (High-Performance Order Storage)

Orders moved from `wp_posts` to dedicated tables. Any theme or plugin that does not
declare compatibility causes WooCommerce to **block the store owner from enabling HPOS**.

```php
add_action( 'before_woocommerce_init', function () {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
            'custom_order_tables',
            __FILE__,   // plugin main file, or the theme's functions.php path
            true
        );
    }
} );
```

Only declare `true` if you never call `get_post_meta()` / `update_post_meta()` on order
IDs. Use the CRUD API instead:

```php
$order = wc_get_order( $order_id );
$value = $order->get_meta( '_custom_field' );
$order->update_meta_data( '_custom_field', $value );
$order->save();
```

## Template routing

WordPress routes every shop view through the theme's `woocommerce.php` when present.
That single shell is enough:

```php
get_header();

$location = ( function_exists( 'is_product' ) && is_product() ) ? 'single' : 'archive';

acme_do_location( $location, function () {
    woocommerce_content();  // renders the correct shop view for the current query
} );

get_footer();
```

To override individual WooCommerce templates, copy them from
`plugins/woocommerce/templates/` into `your-theme/woocommerce/`, preserving the path.
Only copy what you actually change — every copied template is one you must maintain
across WooCommerce updates.

## Content wrappers

WooCommerce prints its own wrapper divs; replace them with the theme's layout:

```php
add_action( 'init', function () {
    remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
    remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

    add_action( 'woocommerce_before_main_content', 'acme_wrapper_start', 10 );
    add_action( 'woocommerce_after_main_content', 'acme_wrapper_end', 10 );

    // Avoid two breadcrumb trails and two BreadcrumbList schemas.
    remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
} );
```

## Elementor Pro WooCommerce Builder

Requires **Elementor Pro** (and, on current plans, a tier that includes ecommerce
widgets). It registers its own `single-product` and `product-archive` locations.

Setup:

1. Elementor → Settings → General → enable **Products** in Post Types.
2. Templates → Theme Builder → **Single Product** / **Product Archive** → Add New.
3. Set Display Conditions (all products, a category, or a specific product).

Known gap: some WooCommerce hooks are not fired inside Elementor-built product
templates. If a third-party plugin injects markup via
`woocommerce_before_single_product_summary` and it disappears, re-attach it:

```php
add_action( 'elementor/widget/render_content', function ( $content, $widget ) {
    if ( 'woocommerce-product-images' === $widget->get_name() ) {
        ob_start();
        do_action( 'woocommerce_before_single_product_summary' );
        $content = ob_get_clean() . $content;
    }
    return $content;
}, 10, 2 );
```

Product attribute archives have no native Theme Builder condition; use a Product Archive
template with broad conditions and exclusions.

## Shop SEO

**Do not emit Product schema from the theme or your widgets.** WooCommerce already
outputs `Product` structured data with offers, price, availability and ratings. A second
`Product` node with a different `@id` creates conflicting offers and Search Console
errors. If Yoast is in play, the official *Yoast WooCommerce SEO* add-on merges the two
into a single graph — recommend it rather than hand-rolling.

Do handle:

- **`noindex` on cart, checkout and account** — thin, session-specific, crawl-budget waste.
- **Product image alt text** — WooCommerce loop thumbnails often ship empty; fall back
  to the product title.
- **Breadcrumbs** — one source only (theme *or* WooCommerce *or* SEO plugin).
- **Faceted navigation** — filtered/sorted URLs (`?orderby=`, `?filter_`) should be
  canonicalized to the clean archive URL.
- **Out-of-stock products** — keep them indexed with correct `availability`; do not 404.

## Performance

WooCommerce enqueues its CSS and the cart-fragments AJAX script site-wide. Dequeuing
them off shop views is one of the largest single wins on a store:

```php
add_action( 'wp_enqueue_scripts', function () {
    if ( ! class_exists( 'WooCommerce' ) ) {
        return;
    }
    $is_shop = is_woocommerce() || is_cart() || is_checkout() || is_account_page();
    if ( apply_filters( 'acme_needs_woocommerce_assets', $is_shop ) ) {
        return;
    }
    wp_dequeue_style( 'woocommerce-general' );
    wp_dequeue_style( 'woocommerce-layout' );
    wp_dequeue_style( 'woocommerce-smallscreen' );
    wp_dequeue_script( 'wc-cart-fragments' );
} );
```

Expose the filter — pages that embed Elementor product widgets outside shop templates
still need the assets.

Other wins: `aspect-ratio` on product images (CLS), `woocommerce_thumbnail` size in
loops rather than full-size, and object caching for `wc_get_product_ids_on_sale()`.

## Safety

Every shop code path must survive WooCommerce being deactivated:

```php
if ( ! class_exists( 'WooCommerce' ) ) {
    return;
}
```

Widgets should render an editor-only explanation rather than a fatal or a blank space:

```php
if ( ! class_exists( 'WooCommerce' ) ) {
    if ( \Elementor\Plugin::$instance->editor->is_edit_mode() ) {
        echo esc_html__( 'WooCommerce is not active.', 'acme' );
    }
    return;
}
```

## Useful hooks

| Hook | Purpose |
| --- | --- |
| `woocommerce_before_main_content` / `_after_main_content` | Layout wrappers |
| `woocommerce_before_shop_loop` / `_after_shop_loop` | Archive header/footer |
| `woocommerce_shop_loop_item_title` | Loop product title |
| `woocommerce_after_shop_loop_item` | Add-to-cart button area |
| `woocommerce_single_product_summary` | Right column on product pages (priority-ordered) |
| `woocommerce_before_single_product_summary` | Gallery area |
| `loop_shop_columns` / `loop_shop_per_page` | Grid density |
| `woocommerce_product_thumbnails` | Gallery thumbnails |
| `before_woocommerce_init` | Feature compatibility declarations |
