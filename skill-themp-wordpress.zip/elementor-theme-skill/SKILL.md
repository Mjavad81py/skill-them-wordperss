---
name: elementor-theme-builder
description: Build production-ready, SEO-optimized, widget-driven WordPress themes for Elementor / Elementor Pro, with optional WooCommerce integration. Use when the user asks to create or modify a WordPress theme that works with Elementor, add Theme Builder location support (header/footer/single/archive), scaffold custom Elementor widgets, dynamic tags or custom controls, build an Elementor shop/WooCommerce theme, or add technical and on-page SEO (meta tags, JSON-LD schema, breadcrumbs, Core Web Vitals) to a theme. Also use for debugging widgets that do not appear in the Elementor panel, styles that do not apply, Theme Builder templates that are ignored, duplicate schema/meta tags, or WooCommerce templates being bypassed.
license: MIT
---

# Elementor Theme Builder

Scaffold and maintain WordPress themes whose layout is authored entirely inside Elementor,
plus the companion plugin that ships the project's custom widgets and dynamic tags. Every
generated theme is SEO-ready by default and WooCommerce-ready on request.

## Golden rules

1. **The theme never contains widgets.** Widgets live in a separate plugin so that switching
   themes never destroys the client's content. This is the single most violated rule; enforce it.
2. **The theme provides locations, not markup.** Templates must be thin shells that hand
   rendering to `elementor_theme_do_location()`, with a plain-WordPress fallback for when
   Elementor Pro is inactive.
3. **Everything user-visible is a control.** No hardcoded strings, colors, or sizes in `render()`.
   If a designer might change it, it is an Elementor control.
4. **Defer to the SEO plugin; never duplicate it.** If Yoast/Rank Math/AIOSEO/SEOPress is
   active it owns titles, descriptions, canonicals and the schema graph — the theme emits
   nothing. Duplicate meta tags and split `Organization` nodes actively harm rankings.
5. **Never emit Product schema.** WooCommerce already does; a second `Product` node creates
   conflicting offers.
6. **Escape on output, never on input.** `esc_html`, `esc_attr`, `esc_url`, `wp_kses_post`.
7. **Guard every entry point** with `defined( 'ABSPATH' ) || exit;`, check
   `did_action( 'elementor/loaded' )` before any Elementor class, and
   `class_exists( 'WooCommerce' )` before any shop call.

## Workflow

### Step 1 — Establish the shape of the project

Ask (or infer) before generating files:

- Project slug, human-readable name, PHP namespace, text domain.
- Elementor **Free** only, or **Pro** available? Theme Builder locations, popups and the
  WooCommerce Builder require Pro. Free-only projects fall back to standard template files.
- Standalone parent theme, or child theme of `hello-elementor`?
- **Is this a shop?** See Step 2 — decide explicitly, never silently.
- Which custom widgets are needed, and what data drives each (post meta, ACF, WP query,
  taxonomy, REST/external API)?
- An SEO plugin in the stack already (Yoast/Rank Math)? Multilingual/RTL? Performance budget?

Default when unspecified: **standalone parent theme + companion widgets plugin + Pro locations
with graceful free fallback + SEO layer on.**

### Step 2 — Decide shop mode

Shop mode controls whether WooCommerce integration is generated at all. Resolve it in
this order:

1. The user said so explicitly → `--shop` or `--no-shop`.
2. The brief contains shop signals → pass `--brief "…"` and let the scaffolder infer.
   Recognized in English and Persian: shop, store, ecommerce, product, cart, checkout,
   catalogue, retail, sell, فروشگاه، محصول، سبد خرید، ووکامرس.
3. **Genuinely ambiguous → ask the user.** Do not guess: retrofitting WooCommerce later is
   cheap, but shipping dead shop code to a content site is sloppy and slows every page.

With shop mode off, `inc/woocommerce.php`, `woocommerce.php` and the Product Grid widget are
not generated and their references are stripped from `functions.php` and the plugin bootstrap.

### Step 3 — Scaffold

```bash
# Content site
python3 scripts/scaffold.py \
  --slug acme-theme --name "Acme Theme" --namespace Acme \
  --author "Acme Studio" --no-shop --out ./build

# Store
python3 scripts/scaffold.py \
  --slug acme-shop --name "Acme Shop" --shop --out ./build

# Let the brief decide
python3 scripts/scaffold.py \
  --slug acme --name "Acme" --brief "online store for handmade shoes" --out ./build
```

It emits `build/<slug>/` (theme) and `build/<slug>-widgets/` (plugin), replacing every
placeholder token. Add `--child` for a `hello-elementor` child theme instead of a parent.
The generated theme already includes the full SEO layer — `inc/seo.php`, `inc/schema.php`
and `inc/performance.php` — wired into `functions.php`.

### Step 3 — Wire the theme to Elementor

Register locations once, in the theme, on `elementor/theme/register_locations`:

```php
add_action( 'elementor/theme/register_locations', function ( $manager ) {
    $manager->register_all_core_location(); // header, footer, single, archive
    $manager->register_location( 'sidebar', [
        'label'           => esc_html__( 'Sidebar', 'acme-theme' ),
        'multiple'        => true,
        'edit_in_content' => false,
    ] );
} );
```

Then every template file follows the same shell pattern — try the location, fall back to PHP:

```php
if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'single' ) ) {
    get_template_part( 'template-parts/content', get_post_type() );
}
```

`elementor_theme_do_location()` returns `true` when a Theme Builder template rendered, so the
fallback runs only when the location is empty or Pro is missing. Read
`references/theme-integration.md` for the full template matrix, `add_theme_support` list,
canvas/full-width page templates, and the `hello_elementor_*` filter surface of the child route.

### Step 5 — Build widgets in the plugin

Every widget extends `\Elementor\Widget_Base` and implements the lifecycle:
`get_name`, `get_title`, `get_icon`, `get_categories`, `get_keywords`,
`get_script_depends` / `get_style_depends`, `register_controls`, `render`,
and optionally `content_template` for live editor preview.

Register on the modern hook (`elementor/widgets/register`, Elementor 3.5+), never the deprecated
`widgets_registered` / `register_widget_type`:

```php
add_action( 'elementor/widgets/register', function ( $widgets_manager ) {
    require_once __DIR__ . '/widgets/class-team-grid-widget.php';
    $widgets_manager->register( new \Acme\Widgets\Team_Grid_Widget() );
} );
```

Give the project its own panel category so widgets are findable:

```php
add_action( 'elementor/elements/categories_registered', function ( $manager ) {
    $manager->add_category( 'acme', [ 'title' => esc_html__( 'Acme', 'acme' ), 'icon' => 'fa fa-plug' ] );
} );
```

`assets/widgets-plugin/widgets/class-example-widget.php` is a complete, copy-ready reference:
repeater items, responsive controls, group controls (typography, background, border, box-shadow),
`{{WRAPPER}}` selectors, conditional control display, and a matching Underscore.js template.
Consult `references/widget-development.md` for the control-type catalog, `{{WRAPPER}}` and
`{{VALUE}}`/`{{SIZE}}{{UNIT}}` token rules, tabbed hover states, and asset-dependency handling.

### Step 6 — Make it dynamic

Widget-driven does not mean static. Choose per data source:

- **Content authored per-instance** → repeater controls inside the widget.
- **Content from posts/CMS** → run `WP_Query` in `render()`, expose query args as controls
  (post type, taxonomy, count, order), and never query in `register_controls()`.
- **Field values reused across widgets** → a custom **dynamic tag** extending
  `\Elementor\Core\DynamicTags\Tag`, registered on `elementor/dynamic_tags/register` after
  `register_group()`. Declare `get_categories()` (e.g. `TEXT_CATEGORY`, `URL_CATEGORY`,
  `IMAGE_CATEGORY`) so the tag appears in the right control's dynamic picker.
- **Content that must be editable inline** → `Group_Control_...` plus `content_template()`.

Enable dynamic support on any control with `'dynamic' => [ 'active' => true ]`.
`references/dynamic-content.md` covers tags, query controls, AJAX/lazy widgets, and caching.

### Step 7 — SEO (already generated; verify and tune)

The scaffolded theme ships the whole layer. What matters is understanding **why it defers**:

- `inc/seo.php` — detects Yoast/Rank Math/AIOSEO/SEOPress/Slim SEO/TSF and, if any is
  active, emits **nothing**. Otherwise outputs meta description, canonical, robots,
  Open Graph and Twitter cards. Duplicate tags are worse than none.
- `inc/schema.php` — one connected JSON-LD `@graph`
  (`Organization` → `WebSite` → `WebPage` → `BreadcrumbList` → `BlogPosting`), built as a
  PHP array and passed through `wp_json_encode()`. Never emits `Product`.
  `acme_get_breadcrumbs()` feeds both the visible trail and the schema, so they cannot drift.
- `inc/performance.php` — LCP preload + `fetchpriority="high"`, lazy-load disabled on the
  hero, emoji/legacy head cruft removed, `font-display: swap` forced onto Elementor's
  Google Fonts, non-critical scripts deferred.

Widget-level rules that protect on-page SEO: heading tags are **controls** defaulting to
`h3`, never hardcoded `<h1>`; images carry real `alt` text; `aspect-ratio` reserves space.
Read `references/seo.md` for the H1 problem in Elementor, `@id` graph wiring, hooking a
plugin's schema filter instead of competing with it, and the Core Web Vitals playbook.

### Step 8 — WooCommerce (shop mode only)

`inc/woocommerce.php` is self-gating — every function checks `class_exists( 'WooCommerce' )`,
so the file is inert if the store plugin is deactivated. It declares theme support (without
it WooCommerce silently falls back to shortcode rendering and ignores all template
overrides), the three opt-in gallery features, **HPOS compatibility** (without it the store
owner is blocked from enabling High-Performance Order Storage), theme content wrappers, a
`shop-sidebar` Elementor location, `noindex` on cart/checkout/account, product-image alt
fallbacks, and off-shop dequeuing of WooCommerce CSS/cart-fragments.

`woocommerce.php` is the routing shell: it hands the view to the Elementor `single`/`archive`
location, falling back to `woocommerce_content()`.

Elementor Pro's WooCommerce Builder registers its own product locations; build Single Product
and Product Archive templates there. See `references/woocommerce.md` for the missing-hook
workaround, faceted-navigation canonicals, and why Product schema stays with WooCommerce.

### Step 9 — Verify before handing off

```bash
python3 scripts/verify.py ./build/acme-shop ./build/acme-shop-widgets
```

Checks PHP syntax (via `php -l` when available), ABSPATH guards, deprecated Elementor APIs,
missing `{{WRAPPER}}` in selectors, unescaped output, leftover placeholders, theme/plugin
headers — plus **SEO**: that a theme emitting meta/schema also defers to SEO plugins, that
JSON-LD goes through `wp_json_encode()`, canonical presence, `language_attributes()`,
`fetchpriority` — and **WooCommerce**: theme support, gallery features, HPOS declaration,
`class_exists` guards, and duplicate Product schema.

Then walk `references/checklist.md` for the manual pass.

## Debugging quick reference

| Symptom | Cause | Fix |
| --- | --- | --- |
| Widget missing from panel | Wrong/deprecated hook, or category never registered | Use `elementor/widgets/register`; add the category on `elementor/elements/categories_registered` |
| Fatal on plugin activation | Elementor classes touched too early | Gate everything behind `did_action( 'elementor/loaded' )` |
| Style controls do nothing | Selector missing `{{WRAPPER}}` | `'{{WRAPPER}} .acme-item' => 'color: {{VALUE}};'` |
| Editor preview blank/stale | No `content_template()`, or PHP-only data | Add the JS template, or set `is_dynamic_content()` to `true` |
| Theme Builder template ignored | Location never registered or never called | Register on `elementor/theme/register_locations` **and** call `elementor_theme_do_location()` |
| Header/footer duplicated | Location rendered inside `get_header()` *and* the template | Render each location exactly once |
| Assets load site-wide | Enqueued unconditionally | Declare via `get_script_depends()` / `get_style_depends()` |
| Two meta descriptions | Theme emits alongside an SEO plugin | Gate output behind the SEO-plugin detector |
| Duplicate `Organization` in schema | Theme + SEO plugin both emit | Defer entirely, or hook `rank_math/json_ld` / `wpseo_schema_*` |
| Rich result never appears | Missing required properties, or marked-up content not visible | Fix in Rich Results Test; only mark up visible content |
| Poor LCP on mobile | Hero image lazy-loaded or not preloaded | Preload + `fetchpriority="high"`, never `loading="lazy"` |
| Multiple H1s | Client set Heading widgets to H1 | Heading tag as a control defaulting to `h3`; debug warning |
| WooCommerce templates ignored | `add_theme_support( 'woocommerce' )` missing | Declare it on `after_setup_theme` |
| Product gallery static | Gallery features not declared | Add the three `wc-product-gallery-*` supports |
| Cannot enable HPOS | No compatibility declaration | `FeaturesUtil::declare_compatibility( 'custom_order_tables', … )` |
| Site fatals without WooCommerce | Unguarded shop calls | Wrap in `class_exists( 'WooCommerce' )` |

## Resources

**scripts/**
- `scaffold.py` — generates the renamed theme + plugin pair; resolves shop mode from
  `--shop` / `--no-shop` / `--brief` keyword inference.
- `verify.py` — static QA gate (syntax, security, deprecated APIs, SEO deference,
  WooCommerce integration, placeholders).

**assets/**
- `theme-boilerplate/` — Elementor-ready theme: locations, canvas/full-width templates, thin
  template shells with fallbacks, SEO + schema + performance modules, self-gating
  WooCommerce integration, RTL-safe stylesheet.
- `widgets-plugin/` — companion plugin: singleton bootstrap with compatibility notices and
  HPOS declaration, category registration, example content widget, query-driven widget,
  WooCommerce product grid, and a dynamic tag.

**references/** (read on demand, not upfront)
- `theme-integration.md` — locations API, template matrix, page templates, child-theme route.
- `widget-development.md` — control catalog, selectors, groups, responsive/hover, assets.
- `dynamic-content.md` — dynamic tags, query controls, AJAX, caching.
- `seo.md` — plugin deference, JSON-LD graphs, on-page rules, Core Web Vitals, validation.
- `woocommerce.md` — shop detection, theme support, HPOS, Elementor WooCommerce Builder,
  shop SEO, performance, safety.
- `checklist.md` — pre-delivery QA and manual test pass.
